
import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/App';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ChartPreview } from '@/components/ui/ChartPreview';
import { AnimatedNumber } from '@/components/ui/AnimatedNumber';
import { formatIndianRupees, formatPercentage } from '@/utils/formatters';
import { Upgrade } from '@/components/modals/Upgrade';
import { db } from '@/services/database';
import { toast } from 'sonner';
import { DatePickerWithRange } from '@/components/ui/DateRangePicker';
import { DateRange } from 'react-day-picker';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  ArrowUpDown, 
  CalendarRange, 
  ChartBarIcon, 
  ChartPieIcon, 
  Mic, 
  MicOff,
  Upload,
  Image
} from 'lucide-react';

const Dashboard = () => {
  const { user, logout } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [showExploreModal, setShowExploreModal] = useState(false);
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: new Date(new Date().setMonth(new Date().getMonth() - 6)),
    to: new Date()
  });
  const [segmentFilter, setSegmentFilter] = useState<string>("all");
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessingVoice, setIsProcessingVoice] = useState(false);
  const [audioMessage, setAudioMessage] = useState<string>("");
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        if (user?.id) {
          const data = await db.getDashboardData(user.id);
          setDashboardData(data);
          setIsLoading(false);
        }
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        toast.error('Failed to load dashboard data');
        setIsLoading(false);
      }
    };

    fetchDashboardData();
  }, [user]);

  const handleUpgradeClick = () => {
    setShowUpgrade(true);
  };

  const handleExploreClick = () => {
    setShowExploreModal(true);
  };

  const handleDateRangeChange = (range: DateRange | undefined) => {
    setDateRange(range);
    // In a real app, this would trigger a data refetch with the new date range
    toast.info("Date range updated. Refreshing dashboard data...");
  };

  const handleSegmentChange = (value: string) => {
    setSegmentFilter(value);
    // In a real app, this would filter the data based on the selected segment
    toast.info(`Segment filter updated to ${value}`);
  };

  const toggleVoiceRecording = async () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = handleAudioStop;
      mediaRecorder.start();
      setIsRecording(true);
      toast.info("Voice recording started...");
    } catch (error) {
      console.error('Error starting voice recording:', error);
      toast.error('Could not access microphone');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsProcessingVoice(true);
    }
  };

  const handleAudioStop = async () => {
    try {
      const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
      
      // In a real app, this would call a speech-to-text API
      // For demo purposes, simulating processing delay and setting a mock response
      setTimeout(() => {
        setAudioMessage("Show me customer segmentation data for Q2");
        setIsProcessingVoice(false);
        toast.success("Voice command processed!");
      }, 2000);
      
      // Clean up the media stream
      if (mediaRecorderRef.current && mediaRecorderRef.current.stream) {
        mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      }
    } catch (error) {
      console.error('Error processing audio:', error);
      setIsProcessingVoice(false);
      toast.error('Failed to process voice command');
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // In a real app, this would process the image to analyze data visualizations
      toast.info("Analyzing uploaded image...");
      setTimeout(() => {
        toast.success("Image analysis complete!");
      }, 2000);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin inline-block w-10 h-10 border-4 border-primary border-t-transparent rounded-full mb-4"></div>
            <h2 className="text-xl font-medium mb-2">Loading Dashboard</h2>
            <p className="text-slate-500">Please wait while we prepare your data...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
            <div>
              <h1 className="text-3xl font-display font-bold mb-2">Dashboard</h1>
              <p className="text-slate-500">Welcome back, {user?.name}</p>
            </div>
            <div className="flex flex-wrap gap-3 mt-4 sm:mt-0">
              <div className="w-full sm:w-auto">
                <DatePickerWithRange date={dateRange} onDateChange={handleDateRangeChange} />
              </div>
              <div className="flex space-x-2">
                <label className="sr-only" htmlFor="segment-filter">Segment Filter</label>
                <Select value={segmentFilter} onValueChange={handleSegmentChange}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select Segment" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Segments</SelectItem>
                    <SelectItem value="high-value">High Value</SelectItem>
                    <SelectItem value="medium-value">Medium Value</SelectItem>
                    <SelectItem value="low-value">Low Value</SelectItem>
                    <SelectItem value="new-customers">New Customers</SelectItem>
                    <SelectItem value="at-risk">At Risk</SelectItem>
                  </SelectContent>
                </Select>
                <Link to="/data-upload">
                  <Button size="sm">
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Data
                  </Button>
                </Link>
              </div>
            </div>
          </div>
          
          {/* Voice and Image Input Controls */}
          <div className="mb-6 flex flex-wrap gap-3">
            <Button 
              variant={isRecording ? "destructive" : "secondary"} 
              size="sm" 
              onClick={toggleVoiceRecording}
              disabled={isProcessingVoice}
              className="flex items-center"
            >
              {isRecording ? (
                <>
                  <MicOff className="h-4 w-4 mr-2" />
                  Stop Recording
                </>
              ) : (
                <>
                  <Mic className="h-4 w-4 mr-2" />
                  Voice Command
                </>
              )}
            </Button>
            
            {isProcessingVoice && (
              <div className="flex items-center">
                <div className="animate-spin mr-2 h-4 w-4 border-2 border-primary border-t-transparent rounded-full"></div>
                <span className="text-sm">Processing voice...</span>
              </div>
            )}
            
            {audioMessage && (
              <div className="text-sm bg-secondary/30 px-3 py-1 rounded-full">
                Voice command: "{audioMessage}"
              </div>
            )}
            
            <div className="relative">
              <input
                type="file"
                id="image-upload"
                accept="image/*"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                onChange={handleImageUpload}
              />
              <Button variant="outline" size="sm" className="flex items-center">
                <Image className="h-4 w-4 mr-2" />
                Upload Visualization
              </Button>
            </div>
          </div>
          
          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardHeader className="p-4 pb-2">
                <CardTitle className="text-sm font-medium text-slate-500">Total Customers</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <div className="text-3xl font-bold">
                  <AnimatedNumber value={dashboardData.summary.totalCustomers} />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="p-4 pb-2">
                <CardTitle className="text-sm font-medium text-slate-500">At-Risk Customers</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <div className="text-3xl font-bold text-amber-500">
                  <AnimatedNumber value={dashboardData.summary.atRiskCustomers} />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="p-4 pb-2">
                <CardTitle className="text-sm font-medium text-slate-500">Churn Rate</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <div className="text-3xl font-bold text-rose-500">
                  <AnimatedNumber value={dashboardData.summary.churnRate} decimals={1} />%
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="p-4 pb-2">
                <CardTitle className="text-sm font-medium text-slate-500">Retention Rate</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <div className="text-3xl font-bold text-emerald-500">
                  <AnimatedNumber value={dashboardData.summary.retentionRate} decimals={1} />%
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="mb-8">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="segments">Segments</TabsTrigger>
              <TabsTrigger value="benchmarks">Benchmarks</TabsTrigger>
              <TabsTrigger value="heatmap">Engagement Heatmap</TabsTrigger>
              <TabsTrigger value="predictions">Predictions</TabsTrigger>
              <TabsTrigger value="analyses">Previous Analyses</TabsTrigger>
              <TabsTrigger value="explore">Explore</TabsTrigger>
            </TabsList>
            
            {/* Overview Tab */}
            <TabsContent value="overview">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Revenue Chart */}
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>Revenue Trend</CardTitle>
                    <CardDescription>
                      Monthly revenue vs target
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ChartPreview 
                        type="bar" 
                        data={dashboardData.revenueData}
                        xKey="month"
                        height={320}
                        series={[
                          { name: "Revenue", dataKey: "revenue", color: "#3b82f6" },
                          { name: "Target", dataKey: "target", color: "#94a3b8" }
                        ]}
                        animate={true}
                        formatter={(value: number) => formatIndianRupees(value)}
                      />
                    </div>
                  </CardContent>
                </Card>
                
                {/* Churn by Category */}
                <Card>
                  <CardHeader>
                    <CardTitle>Churn by Category</CardTitle>
                    <CardDescription>
                      Primary reasons for customer churn
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64">
                      <ChartPreview 
                        type="pie" 
                        data={dashboardData.churnByCategory}
                        colors={dashboardData.churnByCategory.map((c: any) => c.color)}
                        nameKey="name"
                        dataKey="value"
                        animate={true}
                        height={250}
                        formatter={(value: number) => `${value}%`}
                      />
                    </div>
                    <div className="space-y-3 mt-6">
                      {dashboardData.churnByCategory.map((category: any, idx: number) => (
                        <div key={idx} className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: category.color }}></div>
                            <span className="text-sm">{category.name}</span>
                          </div>
                          <div className="text-sm font-medium">
                            {category.value}%
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                
                {/* Recent Analyses */}
                <Card className="lg:col-span-3">
                  <CardHeader>
                    <CardTitle>Recent Analyses</CardTitle>
                    <CardDescription>
                      Your most recent data analyses
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left font-medium text-sm p-2 pl-0">Date</th>
                            <th className="text-left font-medium text-sm p-2">Dataset</th>
                            <th className="text-left font-medium text-sm p-2">Churn Rate</th>
                            <th className="text-left font-medium text-sm p-2">Recommendations</th>
                            <th className="text-right font-medium text-sm p-2 pr-0">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {dashboardData.recentAnalyses.map((analysis: any, idx: number) => (
                            <tr key={idx} className="border-b">
                              <td className="py-3 pl-0">{new Date(analysis.date).toLocaleDateString()}</td>
                              <td className="py-3">{analysis.dataset}</td>
                              <td className="py-3">
                                <span className={analysis.churnRate > 10 ? "text-rose-500 font-medium" : "text-emerald-500 font-medium"}>
                                  {analysis.churnRate}%
                                </span>
                              </td>
                              <td className="py-3">{analysis.recommendations}</td>
                              <td className="py-3 text-right pr-0">
                                <Link to={`/analysis-results/${analysis.id}`}>
                                  <Button size="sm" variant="outline">View Report</Button>
                                </Link>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    {!user?.isPremium && (
                      <div className="mt-4 bg-slate-50 border rounded-md p-4 flex flex-col sm:flex-row items-center justify-between">
                        <div>
                          <h4 className="font-medium text-sm">Access historical analysis</h4>
                          <p className="text-xs text-slate-500">Upgrade to Premium for unlimited access to all past analyses</p>
                        </div>
                        <Button size="sm" className="mt-3 sm:mt-0" onClick={handleUpgradeClick}>
                          Upgrade Now
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            {/* Segments Tab */}
            <TabsContent value="segments">
              <Card>
                <CardHeader>
                  <CardTitle>Customer Segment Comparison</CardTitle>
                  <CardDescription>
                    Analysis of customer segments by value and engagement
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left font-medium text-sm p-2 pl-0">Segment</th>
                          <th className="text-left font-medium text-sm p-2">
                            <div className="flex items-center">
                              Customer Count <ArrowUpDown className="ml-1 h-3 w-3" />
                            </div>
                          </th>
                          <th className="text-left font-medium text-sm p-2">
                            <div className="flex items-center">
                              Churn Rate <ArrowUpDown className="ml-1 h-3 w-3" />
                            </div>
                          </th>
                          <th className="text-left font-medium text-sm p-2">
                            <div className="flex items-center">
                              Lifetime Value <ArrowUpDown className="ml-1 h-3 w-3" />
                            </div>
                          </th>
                          <th className="text-left font-medium text-sm p-2">
                            <div className="flex items-center">
                              Engagement <ArrowUpDown className="ml-1 h-3 w-3" />
                            </div>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {dashboardData.segmentComparison.map((segment: any, idx: number) => (
                          <tr key={idx} className="border-b">
                            <td className="py-3 pl-0 font-medium">{segment.segmentName}</td>
                            <td className="py-3">{segment.customerCount}</td>
                            <td className="py-3">
                              <span className={segment.churnRate > 10 ? "text-rose-500 font-medium" : "text-emerald-500 font-medium"}>
                                {segment.churnRate}%
                              </span>
                            </td>
                            <td className="py-3">{formatIndianRupees(segment.customerLifetimeValue)}</td>
                            <td className="py-3">
                              <div className="flex items-center">
                                <div className="w-24 bg-slate-200 rounded-full h-2 mr-2">
                                  <div 
                                    className={`h-2 rounded-full ${
                                      segment.engagementScore > 7 ? "bg-emerald-500" : 
                                      segment.engagementScore > 5 ? "bg-amber-500" : "bg-rose-500"
                                    }`}
                                    style={{ width: `${segment.engagementScore * 10}%` }}
                                  ></div>
                                </div>
                                <span>{segment.engagementScore}/10</span>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="text-sm font-medium mb-3">Segment Distribution</h4>
                        <div className="h-64">
                          <ChartPreview 
                            type="pie" 
                            data={dashboardData.segmentComparison.map((segment: any) => ({
                              name: segment.segmentName,
                              value: segment.customerCount
                            }))}
                            colors={["#3b82f6", "#f59e0b", "#ef4444"]}
                            nameKey="name"
                            dataKey="value"
                            animate={true}
                            height={240}
                          />
                        </div>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium mb-3">Churn Rate by Segment</h4>
                        <div className="h-64">
                          <ChartPreview 
                            type="bar" 
                            data={dashboardData.segmentComparison.map((segment: any) => ({
                              name: segment.segmentName,
                              value: segment.churnRate
                            }))}
                            xKey="name"
                            height={240}
                            series={[
                              { name: "Churn Rate", dataKey: "value", color: "#ef4444" }
                            ]}
                            animate={true}
                            formatter={(value: number) => `${value}%`}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Benchmarks Tab */}
            <TabsContent value="benchmarks">
              <Card>
                <CardHeader>
                  <CardTitle>Industry Benchmarking</CardTitle>
                  <CardDescription>
                    Compare your performance metrics against industry standards
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {Object.entries(dashboardData.benchmarks).map(([key, values]: [string, any], idx: number) => (
                      <div key={idx} className="bg-slate-50 rounded-lg p-4">
                        <h4 className="font-medium mb-3 capitalize">{key.replace(/([A-Z])/g, ' $1')}</h4>
                        <div className="space-y-4">
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Your Value</span>
                              <span className="text-sm font-medium">{key.includes('Rate') ? `${values.yourValue}%` : formatIndianRupees(values.yourValue)}</span>
                            </div>
                            <div className="w-full bg-slate-200 rounded-full h-2">
                              <div className="bg-primary h-2 rounded-full" style={{ width: '100%' }}></div>
                            </div>
                          </div>
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Industry Average</span>
                              <span className="text-sm font-medium">{key.includes('Rate') ? `${values.industryAverage}%` : formatIndianRupees(values.industryAverage)}</span>
                            </div>
                            <div className="w-full bg-slate-200 rounded-full h-2">
                              <div 
                                className="bg-slate-400 h-2 rounded-full" 
                                style={{ 
                                  width: `${(values.industryAverage / values.yourValue) * 100}%` 
                                }}
                              ></div>
                            </div>
                          </div>
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Top Performers</span>
                              <span className="text-sm font-medium">{key.includes('Rate') ? `${values.topPerformers}%` : formatIndianRupees(values.topPerformers)}</span>
                            </div>
                            <div className="w-full bg-slate-200 rounded-full h-2">
                              <div 
                                className="bg-emerald-500 h-2 rounded-full" 
                                style={{ 
                                  width: `${(values.topPerformers / values.yourValue) * 100}%` 
                                }}
                              ></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-8">
                    <h4 className="text-sm font-medium mb-3">Benchmark Summary</h4>
                    <div className="bg-slate-50 rounded-lg p-4">
                      <div className="space-y-2">
                        <p className="text-sm">Based on our analysis, your business is:</p>
                        <ul className="list-disc list-inside space-y-1 text-sm">
                          <li>
                            <span className="font-medium text-emerald-600">Above average</span> in customer lifetime value (+8.3%)
                          </li>
                          <li>
                            <span className="font-medium text-emerald-600">Above average</span> in customer acquisition cost (-12.5%)
                          </li>
                          <li>
                            <span className="font-medium text-amber-600">Average</span> in churn rate (+/-2.1%)
                          </li>
                          <li>
                            <span className="font-medium text-amber-600">Average</span> in retention rate (+/-2.1%)
                          </li>
                        </ul>
                        <p className="text-sm mt-4">
                          Areas to focus on for improvement:
                        </p>
                        <ul className="list-disc list-inside space-y-1 text-sm">
                          <li>Increasing retention rate to match top performers (+4.3%)</li>
                          <li>Reducing churn rate for "Medium Value" segment (-5.7%)</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Heatmap Tab */}
            <TabsContent value="heatmap">
              <Card>
                <CardHeader>
                  <CardTitle>Customer Engagement Heatmap</CardTitle>
                  <CardDescription>
                    Visualize when and how customers engage with your business
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-center mb-6">
                    <div className="grid grid-cols-5 gap-1">
                      {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map(day => (
                        <div key={day} className="p-2 text-center font-medium">{day}</div>
                      ))}
                      
                      {dashboardData.engagementHeatmap.map((cell: any, idx: number) => {
                        // Calculate color intensity based on value
                        const intensity = Math.min(Math.floor((cell.value / 100) * 255), 255);
                        const bgColor = `rgba(59, 130, 246, ${cell.value / 100})`;
                        
                        return (
                          <div 
                            key={idx} 
                            className="p-2 text-center"
                            style={{ backgroundColor: bgColor }}
                          >
                            <div className="text-xs font-medium">{cell.hour}</div>
                            <div className={`text-sm font-bold ${cell.value > 65 ? 'text-white' : 'text-slate-800'}`}>{cell.value}</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  
                  <div className="flex justify-center items-center space-x-2 mb-6">
                    <div className="w-full h-2 bg-gradient-to-r from-blue-50 to-blue-600 rounded"></div>
                    <div className="flex justify-between w-full text-xs">
                      <span>Low Engagement</span>
                      <span>High Engagement</span>
                    </div>
                  </div>
                  
                  <div className="bg-slate-50 rounded-lg p-4 mt-4">
                    <h4 className="font-medium mb-2">Engagement Insights</h4>
                    <div className="space-y-2 text-sm">
                      <p>• Peak engagement times are on Wednesday around noon (90)</p>
                      <p>• Lowest engagement is on Friday evenings (32)</p>
                      <p>• Morning hours (9AM) show moderate engagement across all weekdays</p>
                      <p>• Tuesday and Wednesday show the highest overall engagement</p>
                    </div>
                    <div className="mt-4">
                      <h5 className="text-sm font-medium mb-2">Recommended Actions:</h5>
                      <div className="space-y-2 text-sm">
                        <p>• Schedule customer outreach campaigns on Tuesdays and Wednesdays</p>
                        <p>• Offer special promotions during low-engagement periods to boost activity</p>
                        <p>• Follow up on high-risk customers during peak engagement hours</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Predictions Tab */}
            <TabsContent value="predictions">
              <Card>
                <CardHeader>
                  <CardTitle>Future Churn Predictions</CardTitle>
                  <CardDescription>
                    Detailed predictions and trend analysis
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-6">
                    Advanced predictions are available in the premium version of BizPredict.
                    Upgrade to unlock XGBoost AI-powered predictions with up to 94% accuracy.
                  </p>

                  <div className="flex justify-center">
                    <Button onClick={handleUpgradeClick}>Upgrade to Premium</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Previous Analyses Tab */}
            <TabsContent value="analyses">
              <Card>
                <CardHeader>
                  <CardTitle>All Previous Analyses</CardTitle>
                  <CardDescription>
                    Complete history of your data analyses
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-6">
                    Complete analysis history is available in the premium version of BizPredict.
                    Upgrade to access all your historical analyses and track progress over time.
                  </p>

                  <div className="flex justify-center">
                    <Button onClick={handleUpgradeClick}>Upgrade to Premium</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Explore Tab */}
            <TabsContent value="explore">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {dashboardData.exploreOptions?.map((option: any) => (
                  <Card key={option.id} className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <div className="bg-blue-100 text-blue-700 p-2 rounded-lg mr-3">
                          {option.icon === "users" && (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                            </svg>
                          )}
                          {option.icon === "trending-up" && (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                            </svg>
                          )}
                          {option.icon === "line-chart" && (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" />
                            </svg>
                          )}
                          {option.icon === "shield" && (
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                            </svg>
                          )}
                        </div>
                        {option.title}
                      </CardTitle>
                      <CardDescription>{option.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button className="w-full" variant="outline" onClick={handleUpgradeClick}>
                        Explore
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
      <Upgrade open={showUpgrade} onOpenChange={setShowUpgrade} />
    </div>
  );
};

export default Dashboard;
