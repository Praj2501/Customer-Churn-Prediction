
import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ChartPreview } from '@/components/ui/ChartPreview';
import { useAuth } from '@/App';

const AnalysisResults = () => {
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [analysisData, setAnalysisData] = useState<any>(null);

  // Generate analysis data
  useEffect(() => {
    setTimeout(() => {
      const mockData = {
        overall: {
          churnRate: 12.5,
          atRiskCount: 45,
          totalCustomers: 360
        },
        predictors: [
          { name: "Contract Length", importance: 34 },
          { name: "Monthly Charges", importance: 28 },
          { name: "Tenure", importance: 17 },
          { name: "Payment Method", importance: 11 },
          { name: "Internet Service", importance: 10 }
        ],
        segments: [
          { name: "Low Risk", count: 265, percentage: 73.6, color: "#10b981" },
          { name: "Medium Risk", count: 58, percentage: 16.1, color: "#f59e0b" },
          { name: "High Risk", count: 37, percentage: 10.3, color: "#ef4444" }
        ],
        timeline: [
          { month: "May", churn: 8.2, retention: 91.8 },
          { month: "Jun", churn: 9.1, retention: 90.9 },
          { month: "Jul", churn: 10.7, retention: 89.3 },
          { month: "Aug", churn: 12.5, retention: 87.5 },
          { month: "Sep", churn: 13.8, retention: 86.2 },
          { month: "Oct", churn: 14.3, retention: 85.7 }
        ],
        atRiskCustomers: [
          { id: 1, name: "Customer 13405", score: 0.92, value: "$1,240/mo", tenure: "8 months" },
          { id: 2, name: "Customer 27613", score: 0.88, value: "$895/mo", tenure: "11 months" },
          { id: 3, name: "Customer 18742", score: 0.85, value: "$1,780/mo", tenure: "6 months" },
          { id: 4, name: "Customer 31459", score: 0.79, value: "$1,150/mo", tenure: "9 months" },
          { id: 5, name: "Customer 22301", score: 0.75, value: "$720/mo", tenure: "14 months" }
        ],
        recommendations: [
          "Offer contract extensions to customers with high monthly spend",
          "Launch a loyalty program targeted at customers in the 6-12 month range",
          "Review pricing strategy for high-value customers with contract lengths under 1 year",
          "Implement satisfaction surveys for at-risk segments",
          "Develop a proactive outreach program for customers with high churn probability"
        ]
      };
      
      setAnalysisData(mockData);
      setIsLoading(false);
    }, 1500);
  }, [id]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin inline-block w-10 h-10 border-4 border-primary border-t-transparent rounded-full mb-4"></div>
            <h2 className="text-xl font-medium mb-2">Loading Analysis Results</h2>
            <p className="text-slate-500">Please wait while we prepare your insights...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="mb-10">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
              <div>
                <h1 className="text-3xl font-display font-bold mb-2">Churn Analysis Results</h1>
                <p className="text-slate-500">Analysis ID: {id}</p>
              </div>
              <div className="flex space-x-3 mt-4 sm:mt-0">
                <Button variant="outline" size="sm">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  Export PDF
                </Button>
                <Link to="/data-upload">
                  <Button variant="outline" size="sm">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    Upload New Data
                  </Button>
                </Link>
              </div>
            </div>
            
            {/* Overview Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <Card>
                <CardHeader className="p-4 pb-2">
                  <CardTitle className="text-lg">Churn Rate</CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="flex items-end">
                    <div className="text-3xl font-bold">{analysisData.overall.churnRate}%</div>
                    <div className="text-rose-500 text-sm ml-2 flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                      </svg>
                      <span>+2.1%</span>
                    </div>
                  </div>
                  <p className="text-sm text-slate-500 mt-2">Projected over next 90 days</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="p-4 pb-2">
                  <CardTitle className="text-lg">At-Risk Customers</CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="flex items-end">
                    <div className="text-3xl font-bold">{analysisData.overall.atRiskCount}</div>
                    <div className="text-slate-500 text-sm ml-2">
                      of {analysisData.overall.totalCustomers}
                    </div>
                  </div>
                  <p className="text-sm text-slate-500 mt-2">Identified as high churn probability</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="p-4 pb-2">
                  <CardTitle className="text-lg">Revenue at Risk</CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-3xl font-bold">$42,350</div>
                  <p className="text-sm text-slate-500 mt-2">Monthly recurring revenue</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="p-4 pb-2">
                  <CardTitle className="text-lg">Retention Opportunity</CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-3xl font-bold">$31,762</div>
                  <p className="text-sm text-slate-500 mt-2">Potential recovery with intervention</p>
                </CardContent>
              </Card>
            </div>
            
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="w-full mb-8 flex flex-wrap">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="segments">Customer Segments</TabsTrigger>
                <TabsTrigger value="risk-factors">Risk Factors</TabsTrigger>
                <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Churn Prediction Over Time */}
                  <Card className="lg:col-span-2">
                    <CardHeader>
                      <CardTitle>Churn Prediction Over Time</CardTitle>
                      <CardDescription>
                        Projected churn rate over the next 6 months
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-80">
                        <ChartPreview 
                          type="area" 
                          data={analysisData.timeline}
                          animate={true}
                          height={320}
                          xKey="month"
                          series={[
                            { name: "churn", dataKey: "churn", color: "#ef4444" }
                          ]}
                        />
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Customer Risk Segments */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Risk Segments</CardTitle>
                      <CardDescription>
                        Customer distribution by churn risk
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-64">
                        <ChartPreview 
                          type="pie" 
                          data={analysisData.segments}
                          colors={analysisData.segments.map((s: any) => s.color)}
                          height={250}
                          nameKey="name"
                          dataKey="percentage"
                          animate={true}
                        />
                      </div>
                      <div className="space-y-3 mt-6">
                        {analysisData.segments.map((segment: any, idx: number) => (
                          <div key={idx} className="flex items-center justify-between">
                            <div className="flex items-center">
                              <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: segment.color }}></div>
                              <span className="text-sm">{segment.name}</span>
                            </div>
                            <div className="text-sm font-medium">
                              {segment.count} ({segment.percentage}%)
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Top Churn Predictors */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Top Churn Predictors</CardTitle>
                      <CardDescription>
                        Factors with highest influence on churn
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {analysisData.predictors.map((predictor: any, idx: number) => (
                          <div key={idx}>
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-sm font-medium">{predictor.name}</span>
                              <span className="text-sm text-slate-500">{predictor.importance}%</span>
                            </div>
                            <div className="w-full bg-slate-100 rounded-full h-2">
                              <div 
                                className="bg-blue-600 h-2 rounded-full" 
                                style={{ width: `${predictor.importance}%` }}
                              ></div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* High-Risk Customers */}
                  <Card className="lg:col-span-2">
                    <CardHeader>
                      <CardTitle>High-Risk Customers</CardTitle>
                      <CardDescription>
                        Top 5 customers most likely to churn
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead>
                            <tr className="border-b">
                              <th className="text-left font-medium text-sm p-2 pl-0">Customer</th>
                              <th className="text-left font-medium text-sm p-2">Churn Probability</th>
                              <th className="text-left font-medium text-sm p-2">Value</th>
                              <th className="text-left font-medium text-sm p-2">Tenure</th>
                              <th className="text-right font-medium text-sm p-2 pr-0">Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {analysisData.atRiskCustomers.map((customer: any, idx: number) => (
                              <tr key={idx} className="border-b">
                                <td className="py-3 pl-0">{customer.name}</td>
                                <td className="py-3">
                                  <div className="flex items-center">
                                    <div 
                                      className="w-full bg-slate-100 rounded-full h-2 mr-2"
                                      style={{ width: '100px' }}
                                    >
                                      <div 
                                        className="bg-rose-500 h-2 rounded-full" 
                                        style={{ width: `${customer.score * 100}%` }}
                                      ></div>
                                    </div>
                                    <span className="text-sm font-medium">{Math.round(customer.score * 100)}%</span>
                                  </div>
                                </td>
                                <td className="py-3">{customer.value}</td>
                                <td className="py-3">{customer.tenure}</td>
                                <td className="py-3 text-right pr-0">
                                  <Button size="sm" variant="outline">Contact</Button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      {!user?.isPremium && (
                        <div className="mt-4 bg-slate-50 border rounded-md p-4 flex flex-col sm:flex-row items-center justify-between">
                          <div>
                            <h4 className="font-medium text-sm">Want to see all at-risk customers?</h4>
                            <p className="text-xs text-slate-500">Upgrade to Premium for complete customer risk analysis</p>
                          </div>
                          <Button size="sm" className="mt-3 sm:mt-0">Upgrade Now</Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="segments">
                <Card>
                  <CardHeader>
                    <CardTitle>Customer Segments Analysis</CardTitle>
                    <CardDescription>
                      Detailed breakdown of customer segments by churn risk
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-6">
                      More detailed segment analysis is available in the premium version of BizPredict.
                      Upgrade to unlock comprehensive customer segments analysis.
                    </p>

                    <div className="flex justify-center">
                      <Button>Upgrade to Premium</Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="risk-factors">
                <Card>
                  <CardHeader>
                    <CardTitle>Risk Factors Analysis</CardTitle>
                    <CardDescription>
                      In-depth analysis of all factors contributing to customer churn
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-6">
                      The full risk factors analysis is available in the premium version of BizPredict.
                      Upgrade to unlock comprehensive risk factor analysis, including correlations and impact scores.
                    </p>

                    <div className="flex justify-center">
                      <Button>Upgrade to Premium</Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="recommendations">
                <Card>
                  <CardHeader>
                    <CardTitle>Recommendations</CardTitle>
                    <CardDescription>
                      Actionable strategies to reduce churn and improve retention
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {analysisData.recommendations.map((recommendation: string, idx: number) => (
                        <div key={idx} className="flex items-start">
                          <div className="bg-blue-100 text-blue-700 p-1 rounded-full mr-3 mt-0.5">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                            </svg>
                          </div>
                          <p className="text-sm">{recommendation}</p>
                        </div>
                      ))}
                    </div>
                    
                    {!user?.isPremium && (
                      <div className="mt-8 bg-slate-50 border rounded-md p-6">
                        <h4 className="font-medium mb-2">Need more detailed recommendations?</h4>
                        <p className="text-sm text-slate-500 mb-4">
                          Upgrade to Premium for customized retention strategies, ROI calculations, and step-by-step implementation guides.
                        </p>
                        <Button>Upgrade to Premium</Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
            
            <div className="mt-8 flex justify-between">
              <Link to="/data-upload">
                <Button variant="outline">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                  </svg>
                  Back to Upload
                </Button>
              </Link>
              <Link to="/">
                <Button variant="outline">
                  Return to Home
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7m-7-7v14" />
                  </svg>
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default AnalysisResults;
