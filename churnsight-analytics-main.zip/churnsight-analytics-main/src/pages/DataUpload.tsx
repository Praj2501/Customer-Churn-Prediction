
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { useAuth } from '@/App';
import { db } from '@/services/database';
import { formatIndianNumber } from '@/utils/formatters';

const DataUpload = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [additionalInfo, setAdditionalInfo] = useState('');
  const [uploadCount, setUploadCount] = useState(0);
  const [maxUploads, setMaxUploads] = useState(10);

  useEffect(() => {
    // Fetch user data to get upload count
    const fetchUserData = async () => {
      if (user && user.email) {
        const userData = await db.findUserByEmail(user.email);
        if (userData) {
          setUploadCount(userData.uploadCount);
          setMaxUploads(userData.maxUploads);
        }
      }
    };
    
    fetchUserData();
  }, [user]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file) {
      toast({
        title: "Error",
        description: "Please select a file to upload",
        variant: "destructive"
      });
      return;
    }

    if (uploadCount >= maxUploads) {
      toast({
        title: "Upload Limit Reached",
        description: "You've reached your upload limit. Please upgrade your plan for more uploads.",
        variant: "destructive"
      });
      return;
    }

    setIsUploading(true);
    
    try {
      // Call the database service to save the dataset
      const result = await db.saveDataset(file, user?.id || '');
      
      if ('error' in result) {
        toast({
          title: "Error",
          description: result.error,
          variant: "destructive"
        });
        setIsUploading(false);
        return;
      }
      
      // Update upload count locally
      setUploadCount(prev => prev + 1);
      
      // Navigate to the results page
      navigate(`/analysis-results/${result.id}`);
      
      toast({
        title: "Success!",
        description: "Your data has been uploaded and analyzed.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem uploading your file. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow py-20 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="mb-10 text-center">
            <h1 className="text-4xl font-display font-bold mb-4">Upload Your Business Data</h1>
            <p className="text-lg text-muted-foreground">
              Upload your customer data to receive detailed churn prediction analysis and actionable insights.
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border p-8 mb-8">
            <div className="mb-6 flex justify-between items-center">
              <h2 className="text-xl font-semibold">Data Upload</h2>
              <div className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm">
                Uploads: {uploadCount}/{maxUploads}
              </div>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium">Upload Data File</label>
                <div className="border-2 border-dashed border-slate-200 rounded-lg p-8 text-center hover:bg-slate-50 transition-colors">
                  {file ? (
                    <div className="flex flex-col items-center justify-center">
                      <div className="bg-blue-100 text-blue-700 p-2 rounded-full mb-2">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                      </div>
                      <p className="text-sm font-medium">{file.name}</p>
                      <p className="text-xs text-slate-500 mt-1">{(file.size / 1024).toFixed(2)} KB</p>
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => setFile(null)}
                        className="mt-2 text-red-500 hover:text-red-700"
                      >
                        Remove
                      </Button>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center">
                      <div className="bg-slate-100 p-2 rounded-full mb-2">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                        </svg>
                      </div>
                      <p className="text-sm font-medium mb-1">Drag and drop your file here or click to browse</p>
                      <p className="text-xs text-slate-500 mb-2">Supported formats: CSV, Excel (.xlsx)</p>
                      <Input
                        type="file"
                        id="file-upload"
                        accept=".csv,.xlsx,.xls"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => document.getElementById('file-upload')?.click()}
                        disabled={uploadCount >= maxUploads}
                      >
                        Select File
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="additional-info" className="text-sm font-medium">Additional Information</label>
                <Textarea
                  id="additional-info"
                  placeholder="Add any specific details about your data or analysis needs..."
                  value={additionalInfo}
                  onChange={(e) => setAdditionalInfo(e.target.value)}
                  className="resize-none"
                  rows={4}
                />
              </div>

              <div className="pt-4">
                <Button
                  type="submit"
                  className="w-full"
                  disabled={isUploading || !file || uploadCount >= maxUploads}
                >
                  {isUploading ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Analyzing...
                    </>
                  ) : (
                    'Upload and Analyze'
                  )}
                </Button>
              </div>
              
              <div className="border-t border-slate-200 pt-4 mt-6">
                <p className="text-xs text-slate-500 text-center">
                  Your data is securely processed and analyzed using industry-leading algorithms, pre-trained on extensive customer data.
                </p>
              </div>
            </form>
          </div>
          
          <div className="mt-8 space-y-4 bg-slate-50 rounded-xl p-6 border border-slate-200">
            <h3 className="font-medium text-lg">How It Works</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex flex-col items-center text-center p-4">
                <div className="bg-blue-100 text-blue-700 p-3 rounded-full mb-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                  </svg>
                </div>
                <h4 className="font-medium">1. Upload Data</h4>
                <p className="text-sm text-slate-500 mt-1">Upload your CSV or Excel file with customer data</p>
              </div>
              <div className="flex flex-col items-center text-center p-4">
                <div className="bg-blue-100 text-blue-700 p-3 rounded-full mb-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
                <h4 className="font-medium">2. Analysis</h4>
                <p className="text-sm text-slate-500 mt-1">Our AI algorithms analyze patterns and risk factors</p>
              </div>
              <div className="flex flex-col items-center text-center p-4">
                <div className="bg-blue-100 text-blue-700 p-3 rounded-full mb-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
                <h4 className="font-medium">3. Get Insights</h4>
                <p className="text-sm text-slate-500 mt-1">Receive detailed churn predictions and strategies</p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default DataUpload;
