
import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/App';
import { db } from '@/services/database';
import { Dataset, Analysis, User } from '@/services/database';
import { formatIndianDate, formatIndianRupees } from '@/utils/formatters';

const AdminDashboard = () => {
  const { toast } = useToast();
  const { user, isAuthenticated } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [analyses, setAnalyses] = useState<Analysis[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        const [usersData, datasetsData, analysesData] = await Promise.all([
          db.getAllUsers(),
          db.getAllDatasets(),
          db.getAllAnalyses()
        ]);
        setUsers(usersData);
        setDatasets(datasetsData);
        setAnalyses(analysesData);
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to fetch database information",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [toast]);

  const handleExportPdf = async (analysisId: string) => {
    try {
      const blob = await db.exportAnalysisAsPdf(analysisId);
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `analysis-${analysisId}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Success",
        description: "PDF export started"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export PDF",
        variant: "destructive"
      });
    }
  };

  const handleExportExcel = async (analysisId: string) => {
    try {
      const blob = await db.exportAnalysisAsExcel(analysisId);
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `analysis-${analysisId}.xlsx`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Success",
        description: "Excel export started"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export Excel file",
        variant: "destructive"
      });
    }
  };

  const handleExportDataset = async (datasetId: string) => {
    try {
      const blob = await db.exportDatasetAsExcel(datasetId);
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `dataset-${datasetId}.xlsx`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Success",
        description: "Dataset export started"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export dataset",
        variant: "destructive"
      });
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <Card className="w-[350px]">
            <CardHeader>
              <CardTitle className="text-xl">Access Denied</CardTitle>
              <CardDescription>You need to log in to access this page.</CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full" onClick={() => window.location.href = "/login"}>
                Go to Login
              </Button>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="mb-10">
            <h1 className="text-4xl font-display font-bold mb-4">Database Admin Dashboard</h1>
            <p className="text-lg text-muted-foreground">
              Access and manage your database information, exports, and analytics.
            </p>
          </div>

          <Tabs defaultValue="users">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="users">Users</TabsTrigger>
              <TabsTrigger value="datasets">Datasets</TabsTrigger>
              <TabsTrigger value="analyses">Analyses</TabsTrigger>
            </TabsList>
            
            <TabsContent value="users">
              <Card>
                <CardHeader>
                  <CardTitle>Registered Users</CardTitle>
                  <CardDescription>All users registered in the system</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="flex justify-center py-8">
                      <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
                    </div>
                  ) : (
                    <Table>
                      <TableCaption>Total {users.length} users found in the database</TableCaption>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Upload Count</TableHead>
                          <TableHead>Last Login</TableHead>
                          <TableHead>Premium</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {users.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                              No users found
                            </TableCell>
                          </TableRow>
                        ) : (
                          users.map((user) => (
                            <TableRow key={user.id}>
                              <TableCell className="font-medium">{user.name}</TableCell>
                              <TableCell>{user.email}</TableCell>
                              <TableCell>{user.uploadCount} / {user.maxUploads}</TableCell>
                              <TableCell>{formatIndianDate(user.lastLogin)}</TableCell>
                              <TableCell>{user.isPremium ? "Yes" : "No"}</TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="datasets">
              <Card>
                <CardHeader>
                  <CardTitle>Uploaded Datasets</CardTitle>
                  <CardDescription>All datasets in the system</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="flex justify-center py-8">
                      <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
                    </div>
                  ) : (
                    <Table>
                      <TableCaption>Total {datasets.length} datasets found in the database</TableCaption>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>File</TableHead>
                          <TableHead>Records</TableHead>
                          <TableHead>Upload Date</TableHead>
                          <TableHead></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {datasets.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                              No datasets found
                            </TableCell>
                          </TableRow>
                        ) : (
                          datasets.map((dataset) => (
                            <TableRow key={dataset.id}>
                              <TableCell className="font-medium">{dataset.name}</TableCell>
                              <TableCell>{dataset.filename}</TableCell>
                              <TableCell>{dataset.recordCount.toLocaleString()}</TableCell>
                              <TableCell>{formatIndianDate(dataset.uploadDate)}</TableCell>
                              <TableCell>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleExportDataset(dataset.id)}
                                >
                                  Export Excel
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="analyses">
              <Card>
                <CardHeader>
                  <CardTitle>Analysis Results</CardTitle>
                  <CardDescription>All completed analyses in the system</CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="flex justify-center py-8">
                      <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
                    </div>
                  ) : (
                    <Table>
                      <TableCaption>Total {analyses.length} analyses found in the database</TableCaption>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Churn Rate</TableHead>
                          <TableHead>Customers</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {analyses.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                              No analyses found
                            </TableCell>
                          </TableRow>
                        ) : (
                          analyses.map((analysis) => (
                            <TableRow key={analysis.id}>
                              <TableCell className="font-medium">{analysis.id.slice(0, 8)}</TableCell>
                              <TableCell>{formatIndianDate(analysis.date)}</TableCell>
                              <TableCell>{analysis.churnRate}%</TableCell>
                              <TableCell>{analysis.totalCustomers.toLocaleString()}</TableCell>
                              <TableCell className="space-x-2">
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  className="mr-2"
                                  onClick={() => handleExportPdf(analysis.id)}
                                >
                                  PDF
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => handleExportExcel(analysis.id)}
                                >
                                  Excel
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default AdminDashboard;
