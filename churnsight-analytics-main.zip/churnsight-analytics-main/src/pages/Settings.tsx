
import { useState } from 'react';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { formatIndianRupees } from '@/utils/formatters';
import { Upgrade } from '@/components/modals/Upgrade';
import { useAuth } from '@/App';

const Settings = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isUpdating, setIsUpdating] = useState(false);
  const [upgradeOpen, setUpgradeOpen] = useState(false);
  
  // Notification settings
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [weeklyReports, setWeeklyReports] = useState(true);
  const [alertNotifications, setAlertNotifications] = useState(true);

  const handleSaveNotifications = () => {
    setIsUpdating(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsUpdating(false);
      
      toast({
        title: "Settings Saved",
        description: "Your notification preferences have been updated.",
      });
    }, 1000);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="mb-10">
            <h1 className="text-3xl font-display font-bold mb-2">Settings</h1>
            <p className="text-slate-500">Manage your account settings and preferences</p>
          </div>

          <Tabs defaultValue="notifications" className="w-full">
            <TabsList className="mb-8">
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
              <TabsTrigger value="billing">Billing</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
            </TabsList>
            
            <TabsContent value="notifications">
              <Card>
                <CardHeader>
                  <CardTitle>Notification Preferences</CardTitle>
                  <CardDescription>
                    Manage how you receive notifications and alerts
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium">Email Notifications</h4>
                        <p className="text-sm text-slate-500">Receive notifications via email</p>
                      </div>
                      <Switch 
                        checked={emailNotifications} 
                        onCheckedChange={setEmailNotifications} 
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium">Weekly Reports</h4>
                        <p className="text-sm text-slate-500">Receive weekly summary reports</p>
                      </div>
                      <Switch 
                        checked={weeklyReports} 
                        onCheckedChange={setWeeklyReports} 
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium">Churn Risk Alerts</h4>
                        <p className="text-sm text-slate-500">Get notified when customers are at high risk</p>
                      </div>
                      <Switch 
                        checked={alertNotifications} 
                        onCheckedChange={setAlertNotifications} 
                      />
                    </div>
                    
                    <div className="pt-4 flex justify-end">
                      <Button onClick={handleSaveNotifications} disabled={isUpdating}>
                        {isUpdating ? "Saving..." : "Save Preferences"}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="billing">
              <Card>
                <CardHeader>
                  <CardTitle>Subscription Plan</CardTitle>
                  <CardDescription>
                    Manage your subscription and billing information
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="bg-slate-50 rounded-lg p-6 mb-6">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-medium">Current Plan: {user?.isPremium ? 'Premium' : 'Basic'}</h3>
                      <div className="font-bold text-xl">
                        {user?.isPremium ? formatIndianRupees(24999) : formatIndianRupees(9999)}
                        <span className="text-sm font-normal text-slate-500">/month</span>
                      </div>
                    </div>
                    
                    {user?.isPremium ? (
                      <div className="text-sm text-slate-600">
                        You're currently on the Premium plan with access to all features.
                      </div>
                    ) : (
                      <div className="text-sm text-slate-600 mb-4">
                        Upgrade to Premium for full access to all advanced features and unlimited analysis.
                      </div>
                    )}
                    
                    {!user?.isPremium && (
                      <Button onClick={() => setUpgradeOpen(true)} className="mt-4">
                        Upgrade to Premium
                      </Button>
                    )}
                  </div>
                  
                  <div className="border-t pt-6">
                    <h4 className="font-medium mb-4">Payment Method</h4>
                    <div className="bg-white border rounded-md p-4 flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="bg-slate-100 p-2 rounded mr-4">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                          </svg>
                        </div>
                        <div>
                          <div className="font-medium">•••• •••• •••• 4242</div>
                          <div className="text-xs text-slate-500">Expires 12/2025</div>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="security">
              <Card>
                <CardHeader>
                  <CardTitle>Security Settings</CardTitle>
                  <CardDescription>
                    Manage your account security and password
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-medium mb-2">Change Password</h4>
                      <Button variant="outline">Update Password</Button>
                    </div>
                    
                    <div className="pt-4 border-t">
                      <h4 className="font-medium mb-2">Two-Factor Authentication</h4>
                      <p className="text-sm text-slate-500 mb-2">
                        Add an extra layer of security to your account
                      </p>
                      <Button>Enable 2FA</Button>
                    </div>
                    
                    <div className="pt-4 border-t">
                      <h4 className="font-medium mb-2 text-red-600">Danger Zone</h4>
                      <p className="text-sm text-slate-500 mb-2">
                        Permanently delete your account and all associated data
                      </p>
                      <Button variant="destructive">Delete Account</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
      <Upgrade open={upgradeOpen} onOpenChange={setUpgradeOpen} />
    </div>
  );
};

export default Settings;
