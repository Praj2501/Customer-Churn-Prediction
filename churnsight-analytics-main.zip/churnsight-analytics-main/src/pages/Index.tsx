
import Hero from "@/components/sections/Hero";
import Features from "@/components/sections/Features";
import Dashboard from "@/components/sections/Dashboard";
import HealthScore from "@/components/sections/HealthScore";
import Contact from "@/components/sections/Contact";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <Hero />
        <Features />
        <Dashboard />
        <HealthScore />
        <Contact />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
