
import { mongodb } from './mongodb';

// Data interfaces
export interface Customer {
  id: string;
  name: string;
  email: string;
  tenure: number; // in months
  monthlySpend: number;
  products: string[];
  lastActivity: Date;
  churnProbability?: number;
}

export interface Dataset {
  id: string;
  name: string;
  filename: string;
  uploadedBy: string;
  uploadDate: Date;
  recordCount: number;
  fields: string[];
}

export interface Analysis {
  id: string;
  datasetId: string;
  date: Date;
  churnRate: number;
  atRiskCount: number;
  totalCustomers: number;
  segments: {
    name: string;
    count: number;
    percentage: number;
  }[];
  predictors: {
    name: string;
    importance: number;
  }[];
  recommendations: string[];
}

export interface User {
  id: string;
  email: string;
  name: string;
  isPremium: boolean;
  uploadCount: number; // Track uploads
  maxUploads: number; // Limit uploads
  createdAt: Date;
  lastLogin: Date;
}

// Database service
class DatabaseService {
  // User management
  async findUserByEmail(email: string): Promise<User | null> {
    return mongodb.findUserByEmail(email);
  }
  
  async createUser(userData: Omit<User, 'id' | 'createdAt' | 'lastLogin' | 'uploadCount' | 'maxUploads'>): Promise<User> {
    const newUser = {
      ...userData,
      uploadCount: 0,
      maxUploads: 10, // Set limit to 10 uploads
      createdAt: new Date(),
      lastLogin: new Date()
    };
    return mongodb.createUser(newUser);
  }
  
  async updateUserLoginTime(userId: string): Promise<void> {
    return mongodb.updateUserLoginTime(userId);
  }
  
  async updateUserPremiumStatus(userId: string, isPremium: boolean): Promise<void> {
    return mongodb.updateUserPremiumStatus(userId, isPremium);
  }
  
  // Dataset management
  async saveDataset(file: File, userId: string): Promise<Dataset | {error: string}> {
    // Check upload limits
    const user = await this.findUserByEmail(userId);
    if (user && user.uploadCount >= user.maxUploads) {
      return { error: "You have reached your upload limit. Please upgrade your plan for more uploads." };
    }
    
    // Increment upload count
    await mongodb.incrementUserUploadCount(userId);
    
    return mongodb.saveDataset(file, userId);
  }
  
  async getDatasetsByUser(userId: string): Promise<Dataset[]> {
    return mongodb.getDatasetsByUser(userId);
  }
  
  // Analysis management
  async saveAnalysis(analysis: Omit<Analysis, 'id'>): Promise<Analysis> {
    return mongodb.saveAnalysis(analysis);
  }
  
  async getAnalysisByUser(userId: string): Promise<Analysis[]> {
    return mongodb.getAnalysisByUser(userId);
  }
  
  async getAnalysisById(id: string): Promise<Analysis | null> {
    return mongodb.getAnalysisById(id);
  }
  
  // Export functionality
  async exportAnalysisAsPdf(analysisId: string): Promise<Blob> {
    // This would call a server-side API to generate a PDF
    return mongodb.exportAnalysisAsPdf(analysisId);
  }
  
  async exportAnalysisAsExcel(analysisId: string): Promise<Blob> {
    // This would call a server-side API to generate an Excel file
    return mongodb.exportAnalysisAsExcel(analysisId);
  }
  
  async exportDatasetAsExcel(datasetId: string): Promise<Blob> {
    // This would call a server-side API to export the dataset
    return mongodb.exportDatasetAsExcel(datasetId);
  }
  
  // Database admin access functions
  async getAllUsers(): Promise<User[]> {
    return mongodb.getAllUsers();
  }
  
  async getAllDatasets(): Promise<Dataset[]> {
    return mongodb.getAllDatasets();
  }
  
  async getAllAnalyses(): Promise<Analysis[]> {
    return mongodb.getAllAnalyses();
  }
  
  // Dashboard related functions
  async getDashboardData(userId: string): Promise<any> {
    // In a real app, this would fetch actual data from MongoDB
    return {
      summary: {
        totalCustomers: 1247,
        atRiskCustomers: 157,
        churnRate: 12.6,
        retentionRate: 87.4
      },
      revenueData: [
        { month: "Jan", revenue: 4250000, target: 4000000 },
        { month: "Feb", revenue: 4520000, target: 4200000 },
        { month: "Mar", revenue: 4890000, target: 4400000 },
        { month: "Apr", revenue: 4670000, target: 4600000 },
        { month: "May", revenue: 4980000, target: 4800000 },
        { month: "Jun", revenue: 5350000, target: 5000000 }
      ],
      churnByCategory: [
        { name: "Price", value: 38, color: "#ef4444" },
        { name: "Competition", value: 24, color: "#f59e0b" },
        { name: "Service", value: 18, color: "#3b82f6" },
        { name: "Product", value: 12, color: "#10b981" },
        { name: "Other", value: 8, color: "#8b5cf6" }
      ],
      segmentComparison: [
        { 
          segmentName: "High Value", 
          customerCount: 342, 
          churnRate: 5.2, 
          customerLifetimeValue: 9800, 
          engagementScore: 8.7 
        },
        { 
          segmentName: "Medium Value", 
          customerCount: 523, 
          churnRate: 10.4, 
          customerLifetimeValue: 4200, 
          engagementScore: 6.3 
        },
        { 
          segmentName: "Low Value", 
          customerCount: 382, 
          churnRate: 18.7, 
          customerLifetimeValue: 1500, 
          engagementScore: 3.8 
        }
      ],
      benchmarks: {
        churnRate: { 
          yourValue: 12.6, 
          industryAverage: 15.2, 
          topPerformers: 8.3 
        },
        retentionRate: { 
          yourValue: 87.4, 
          industryAverage: 84.8, 
          topPerformers: 91.7 
        },
        customerAcquisitionCost: { 
          yourValue: 2800, 
          industryAverage: 3200, 
          topPerformers: 2100 
        },
        customerLifetimeValue: { 
          yourValue: 5200, 
          industryAverage: 4800, 
          topPerformers: 7300 
        }
      },
      engagementHeatmap: [
        { day: "Mon", hour: "9AM", value: 45 },
        { day: "Mon", hour: "12PM", value: 78 },
        { day: "Mon", hour: "3PM", value: 56 },
        { day: "Mon", hour: "6PM", value: 34 },
        { day: "Tue", hour: "9AM", value: 52 },
        { day: "Tue", hour: "12PM", value: 85 },
        { day: "Tue", hour: "3PM", value: 62 },
        { day: "Tue", hour: "6PM", value: 41 },
        { day: "Wed", hour: "9AM", value: 58 },
        { day: "Wed", hour: "12PM", value: 90 },
        { day: "Wed", hour: "3PM", value: 69 },
        { day: "Wed", hour: "6PM", value: 47 },
        { day: "Thu", hour: "9AM", value: 54 },
        { day: "Thu", hour: "12PM", value: 82 },
        { day: "Thu", hour: "3PM", value: 64 },
        { day: "Thu", hour: "6PM", value: 39 },
        { day: "Fri", hour: "9AM", value: 49 },
        { day: "Fri", hour: "12PM", value: 75 },
        { day: "Fri", hour: "3PM", value: 59 },
        { day: "Fri", hour: "6PM", value: 32 }
      ],
      recentAnalyses: [
        { 
          id: "a1b2c3d4", 
          date: "2023-07-15", 
          dataset: "Telecom Customers Q2", 
          churnRate: 11.2,
          recommendations: 5
        },
        { 
          id: "e5f6g7h8", 
          date: "2023-06-30", 
          dataset: "E-commerce Shoppers", 
          churnRate: 14.8,
          recommendations: 7
        },
        { 
          id: "i9j0k1l2", 
          date: "2023-06-15", 
          dataset: "SaaS Subscribers", 
          churnRate: 9.3,
          recommendations: 4
        }
      ],
      exploreOptions: [
        {
          id: "customer-segments",
          title: "Customer Segments",
          description: "Analyze customer groups by behavior, value, and risk",
          icon: "users"
        },
        {
          id: "revenue-impact",
          title: "Revenue Impact Analysis",
          description: "Calculate financial impact of churn across segments",
          icon: "trending-up"
        },
        {
          id: "predictive-analysis",
          title: "Predictive Analysis",
          description: "See future churn projections based on current trends",
          icon: "line-chart"
        },
        {
          id: "retention-strategies",
          title: "Retention Strategies",
          description: "Recommended actions tailored to your business",
          icon: "shield"
        }
      ]
    };
  }
}

export const db = new DatabaseService();
export default db;
