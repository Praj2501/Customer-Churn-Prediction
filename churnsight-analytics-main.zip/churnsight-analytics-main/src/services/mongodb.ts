
// MongoDB service implementation

import { Customer, Dataset, Analysis, User } from './database';

// Mock datasets - these would be stored in MongoDB in a real app
const sampleDatasets = {
  "telecom_churn.csv": {
    fields: [
      "customerID", "gender", "seniorCitizen", "partner", "dependents", 
      "tenure", "phoneService", "multipleLines", "internetService", 
      "onlineSecurity", "onlineBackup", "deviceProtection", "techSupport", 
      "streamingTV", "streamingMovies", "contract", "paperlessBilling", 
      "paymentMethod", "monthlyCharges", "totalCharges", "churn"
    ],
    recordCount: 7043
  },
  "amazon_vfl_reviews.csv": {
    fields: [
      "reviewerID", "asin", "reviewerName", "helpful", "reviewText", 
      "overall", "summary", "unixReviewTime", "reviewTime", "category"
    ],
    recordCount: 12587
  },
  "shopping_trends.csv": {
    fields: [
      "customerID", "age", "gender", "item_purchased", "category", 
      "purchase_amount", "location", "size", "color", "season", 
      "review_rating", "subscription_status", "shipping_type", "discount_applied", 
      "promo_code_used", "previous_purchases", "payment_method", "frequency_of_purchases"
    ],
    recordCount: 3941
  }
};

// Simulate MongoDB storage with local storage
let users: User[] = [];
let datasets: Dataset[] = [];
let analyses: Analysis[] = [];

class MongoDB {
  // User management
  async findUserByEmail(email: string): Promise<User | null> {
    console.log(`[MongoDB] Finding user by email: ${email}`);
    const user = users.find(u => u.email === email);
    return user || null;
  }
  
  async createUser(userData: any): Promise<User> {
    console.log(`[MongoDB] Creating user: ${userData.email}`);
    const newUser: User = {
      ...userData,
      id: Math.random().toString(36).substring(2, 15),
      uploadCount: 0,
      maxUploads: 10,
      createdAt: new Date(),
      lastLogin: new Date()
    };
    users.push(newUser);
    return newUser;
  }
  
  async updateUserLoginTime(userId: string): Promise<void> {
    const user = users.find(u => u.id === userId);
    if (user) {
      user.lastLogin = new Date();
    }
  }
  
  async updateUserPremiumStatus(userId: string, isPremium: boolean): Promise<void> {
    console.log(`[MongoDB] Updating premium status for user ${userId} to ${isPremium}`);
    const user = users.find(u => u.id === userId);
    if (user) {
      user.isPremium = isPremium;
      // If upgrading to premium, increase upload limit
      if (isPremium) {
        user.maxUploads = 50; // Premium users get more uploads
      }
    }
  }
  
  async incrementUserUploadCount(userId: string): Promise<void> {
    const user = users.find(u => u.id === userId);
    if (user) {
      user.uploadCount++;
    }
  }
  
  // Dataset management
  async saveDataset(file: File, userId: string): Promise<Dataset> {
    console.log(`[MongoDB] Saving dataset: ${file.name} for user ${userId}`);
    
    const dataset: Dataset = {
      id: Math.random().toString(36).substring(2, 15),
      name: file.name.split('.')[0],
      filename: file.name,
      uploadedBy: userId,
      uploadDate: new Date(),
      recordCount: Math.floor(Math.random() * 10000) + 1000,
      fields: []
    };
    
    // Set fields based on known sample datasets
    if (sampleDatasets[file.name as keyof typeof sampleDatasets]) {
      dataset.fields = sampleDatasets[file.name as keyof typeof sampleDatasets].fields;
      dataset.recordCount = sampleDatasets[file.name as keyof typeof sampleDatasets].recordCount;
    }
    
    datasets.push(dataset);
    return dataset;
  }
  
  async getDatasetsByUser(userId: string): Promise<Dataset[]> {
    console.log(`[MongoDB] Getting datasets for user: ${userId}`);
    return datasets.filter(d => d.uploadedBy === userId);
  }
  
  // Analysis management
  async saveAnalysis(analysis: Omit<Analysis, 'id'>): Promise<Analysis> {
    const id = Math.random().toString(36).substring(2, 15);
    console.log(`[MongoDB] Saving analysis with ID: ${id}`);
    const newAnalysis = { ...analysis, id };
    analyses.push(newAnalysis as Analysis);
    return newAnalysis as Analysis;
  }
  
  async getAnalysisByUser(userId: string): Promise<Analysis[]> {
    console.log(`[MongoDB] Getting analyses for user: ${userId}`);
    // In a real app, we'd join with datasets to filter by user
    const userDatasets = datasets.filter(d => d.uploadedBy === userId);
    const datasetIds = userDatasets.map(d => d.id);
    return analyses.filter(a => datasetIds.includes(a.datasetId));
  }
  
  async getAnalysisById(id: string): Promise<Analysis | null> {
    console.log(`[MongoDB] Getting analysis by ID: ${id}`);
    const analysis = analyses.find(a => a.id === id);
    return analysis || null;
  }
  
  // Export functionality
  async exportAnalysisAsPdf(analysisId: string): Promise<Blob> {
    console.log(`[MongoDB] Exporting analysis as PDF: ${analysisId}`);
    // In a real app, this would generate a PDF server-side
    // For now, we'll create a mock PDF blob
    return new Blob(['Mock PDF data'], { type: 'application/pdf' });
  }
  
  async exportAnalysisAsExcel(analysisId: string): Promise<Blob> {
    console.log(`[MongoDB] Exporting analysis as Excel: ${analysisId}`);
    // In a real app, this would generate an Excel file server-side
    return new Blob(['Mock Excel data'], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  }
  
  async exportDatasetAsExcel(datasetId: string): Promise<Blob> {
    console.log(`[MongoDB] Exporting dataset as Excel: ${datasetId}`);
    return new Blob(['Mock Dataset Excel data'], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  }
  
  // Admin access
  async getAllUsers(): Promise<User[]> {
    return users;
  }
  
  async getAllDatasets(): Promise<Dataset[]> {
    return datasets;
  }
  
  async getAllAnalyses(): Promise<Analysis[]> {
    return analyses;
  }
}

export const mongodb = new MongoDB();
export default mongodb;
