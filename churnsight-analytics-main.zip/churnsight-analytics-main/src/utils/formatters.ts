
/**
 * Format a number as Indian Rupees (INR)
 */
export const formatIndianRupees = (amount: number): string => {
  const formatter = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  });
  
  return formatter.format(amount);
};

/**
 * Format a number as a percentage
 */
export const formatPercentage = (value: number, decimals: number = 1): string => {
  return `${value.toFixed(decimals)}%`;
};

/**
 * Format a large number with lakhs and crores (Indian number system)
 */
export const formatIndianNumber = (value: number): string => {
  if (value >= 10000000) {
    return `${(value / 10000000).toFixed(2)} Cr`;
  } else if (value >= 100000) {
    return `${(value / 100000).toFixed(2)} Lakh`;
  } else if (value >= 1000) {
    return `${(value / 1000).toFixed(1)}K`;
  } else {
    return value.toLocaleString('en-IN');
  }
};

/**
 * Format a date in Indian style (DD/MM/YYYY)
 */
export const formatIndianDate = (date: Date | string): string => {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('en-IN');
};

/**
 * Format a phone number in Indian style
 */
export const formatIndianPhoneNumber = (phone: string): string => {
  // Remove non-digit characters
  const digits = phone.replace(/\D/g, '');
  
  // Format as: +91 XXXXX XXXXX
  if (digits.length === 10) {
    return `+91 ${digits.substring(0, 5)} ${digits.substring(5)}`;
  } else if (digits.length > 10) {
    return `+${digits.substring(0, 2)} ${digits.substring(2, 7)} ${digits.substring(7, 12)}`;
  }
  
  // Return original if not valid
  return phone;
};

/**
 * Convert a number to words in Indian numbering style
 */
export const numberToIndianWords = (num: number): string => {
  const single = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  
  if (num === 0) return 'Zero';
  
  const convertLessThanOneThousand = (num: number): string => {
    if (num < 20) {
      return single[num];
    }
    
    const digit = num % 10;
    if (num < 100) {
      return tens[Math.floor(num / 10)] + (digit > 0 ? ' ' + single[digit] : '');
    }
    
    return single[Math.floor(num / 100)] + ' Hundred' + (num % 100 > 0 ? ' ' + convertLessThanOneThousand(num % 100) : '');
  };
  
  let result = '';
  let crore = Math.floor(num / 10000000);
  let lakh = Math.floor((num % 10000000) / 100000);
  let thousand = Math.floor((num % 100000) / 1000);
  let remaining = num % 1000;
  
  if (crore > 0) {
    result += convertLessThanOneThousand(crore) + ' Crore ';
  }
  
  if (lakh > 0) {
    result += convertLessThanOneThousand(lakh) + ' Lakh ';
  }
  
  if (thousand > 0) {
    result += convertLessThanOneThousand(thousand) + ' Thousand ';
  }
  
  if (remaining > 0) {
    result += convertLessThanOneThousand(remaining);
  }
  
  return result.trim();
};

/**
 * Save chart/graph as image
 */
export const saveChartAsImage = (chartId: string, fileName: string = 'chart.png') => {
  const chartElement = document.getElementById(chartId);
  if (!chartElement) return null;
  
  // Use html2canvas or similar library in a real implementation
  // For demonstration, let's create a simple method
  const canvas = document.createElement('canvas');
  canvas.width = chartElement.offsetWidth;
  canvas.height = chartElement.offsetHeight;
  const context = canvas.getContext('2d');
  
  if (context) {
    // Simple capture of the element
    const svgData = new XMLSerializer().serializeToString(chartElement);
    const img = new Image();
    
    // Create a data URL from the SVG
    const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    
    // Set up the image load handler
    img.onload = function() {
      context.drawImage(img, 0, 0);
      URL.revokeObjectURL(url);
      
      // Convert canvas to blob and download
      canvas.toBlob(function(blob) {
        if (blob) {
          const link = document.createElement('a');
          link.download = fileName;
          link.href = URL.createObjectURL(blob);
          link.click();
          URL.revokeObjectURL(link.href);
        }
      });
    };
    
    img.src = url;
  }
};
