
import { useState, useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';

interface AnimatedNumberProps {
  value: number;
  duration?: number;
  className?: string;
  formatter?: (value: number) => string;
  decimals?: number;
}

export function AnimatedNumber({
  value,
  duration = 1000,
  className,
  formatter = (value: number) => value.toString(),
  decimals = 0
}: AnimatedNumberProps) {
  const [displayValue, setDisplayValue] = useState(0);
  const startTimeRef = useRef<number | null>(null);
  const initialValueRef = useRef(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    initialValueRef.current = displayValue;
    startTimeRef.current = null;
    
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
    }

    // Animation function
    const animate = (timestamp: number) => {
      if (!startTimeRef.current) {
        startTimeRef.current = timestamp;
      }

      const elapsed = timestamp - startTimeRef.current;
      const progress = Math.min(elapsed / duration, 1);
      
      // Easing function (cubic out)
      const easedProgress = 1 - Math.pow(1 - progress, 3);
      
      const currentValue = initialValueRef.current + (value - initialValueRef.current) * easedProgress;
      setDisplayValue(currentValue);

      if (progress < 1) {
        rafRef.current = requestAnimationFrame(animate);
      }
    };

    rafRef.current = requestAnimationFrame(animate);

    return () => {
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, [value, duration]);

  const formattedValue = formatter(
    decimals === 0 
      ? Math.round(displayValue) 
      : parseFloat(displayValue.toFixed(decimals))
  );

  return (
    <span className={cn("font-display font-bold", className)}>
      {formattedValue}
    </span>
  );
}

export default AnimatedNumber;
