
import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, HelpCircle, Search, Mic, Image, Globe, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface Message {
  id: string;
  content: string;
  sender: "user" | "bot";
  timestamp: Date;
}

interface ChatbotProps {
  position?: string;
}

const initialMessages: Message[] = [
  {
    id: "1",
    content: "👋 Hi there! I'm your BizPredict assistant powered by Gemini 1.5. How can I help with your churn prediction needs today?",
    sender: "bot",
    timestamp: new Date(),
  },
];

const faqItems = [
  {
    question: "How does the Gemini 1.5 churn prediction work?",
    answer: "Our Gemini 1.5 powered system uses advanced machine learning algorithms to analyze customer data patterns and identify those at risk of churning. We examine factors like engagement, spending patterns, and behavioral signals to create accurate predictions."
  },
  {
    question: "What data formats do you support?",
    answer: "We support CSV and Excel files containing customer data. Your data should include columns for customer attributes like tenure, spending patterns, demographics, and engagement metrics for the best prediction results."
  },
  {
    question: "How accurate are the Gemini 1.5 predictions?",
    answer: "Our Gemini 1.5 model achieves 85-90% accuracy in most industry sectors. The accuracy improves as more data is provided and as the model learns from your specific customer patterns."
  },
  {
    question: "How much does it cost?",
    answer: "Our basic plan starts at ₹9,999 per month, while our premium plan is ₹24,999 per month with additional features like unlimited analysis, priority support, and advanced retention strategies."
  },
  {
    question: "Can I export the results?",
    answer: "Yes! Premium users can export analysis results in both PDF and Excel formats for easy sharing and further analysis. The exports include visualizations, key metrics, and recommended retention actions."
  },
  {
    question: "How is my data stored?",
    answer: "Your data is stored securely in your local environment. We do not store your customer data on our servers, ensuring complete privacy and compliance with data protection regulations."
  },
  {
    question: "What makes Gemini 1.5 different from other AI models?",
    answer: "Gemini 1.5 is Google's advanced multimodal AI model with 1.5 trillion parameters, offering unparalleled understanding of customer behavior patterns. It can process text, tables, and even images of your data visualizations to provide deeper insights than traditional models."
  },
  {
    question: "Can I customize the prediction models?",
    answer: "Yes, Premium users can customize which factors are weighted more heavily in the churn prediction algorithm, adapting it to your specific business needs and customer base."
  },
  {
    question: "Does Gemini 1.5 support voice commands?",
    answer: "Yes, our enhanced Gemini 1.5 integration supports voice input. You can speak your questions or commands, and the system will process them just like typed queries."
  },
  {
    question: "Can I upload charts and visualizations for analysis?",
    answer: "Yes, with our image upload feature, you can upload your existing charts and visualizations. Gemini 1.5 will analyze them and provide insights and recommendations based on the data in your images."
  },
  {
    question: "Which languages are supported?",
    answer: "Our system supports multiple languages including English, Hindi, Spanish, French, German, Japanese, and Chinese. This makes it accessible for international businesses and multilingual teams."
  },
  {
    question: "What industry-specific knowledge does Gemini 1.5 have?",
    answer: "Gemini 1.5 is trained on specialized data for telecom, retail, e-commerce, SaaS, and banking sectors. We offer industry-specific analysis modes that apply best practices and benchmarks for your particular vertical."
  },
  {
    question: "How can I connect Gemini 1.5 to my existing knowledge base?",
    answer: "Premium users can connect Gemini 1.5 to their existing knowledge bases and CRM systems. This allows the AI to provide more contextualized insights by leveraging your proprietary business data."
  },
  {
    question: "What features are exclusive to Premium users?",
    answer: "Premium users get access to advanced features including unlimited analysis, historical data, customizable models, industry benchmarking, voice interaction, image analysis, knowledge base integration, and priority support."
  }
];

const supportedLanguages = [
  { code: "en", name: "English" },
  { code: "hi", name: "Hindi" },
  { code: "es", name: "Spanish" },
  { code: "fr", name: "French" },
  { code: "de", name: "German" },
  { code: "ja", name: "Japanese" },
  { code: "zh", name: "Chinese" }
];

const industryModes = [
  { id: "general", name: "General" },
  { id: "telecom", name: "Telecom" },
  { id: "retail", name: "Retail" },
  { id: "ecommerce", name: "E-commerce" },
  { id: "saas", name: "SaaS" },
  { id: "banking", name: "Banking" }
];

export function Chatbot({ position = "bottom-right" }: ChatbotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState("chat");
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredFaq, setFilteredFaq] = useState(faqItems);
  const [isRecording, setIsRecording] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState("en");
  const [selectedMode, setSelectedMode] = useState("general");
  const [showImageUploader, setShowImageUploader] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsProcessing(true);

    // Simulate response delay
    setTimeout(() => {
      // Predefined responses based on keywords
      let botResponse = "";

      const lowercaseInput = input.toLowerCase();

      if (lowercaseInput.includes("hello") || lowercaseInput.includes("hi")) {
        botResponse = `Hello! I'm your BizPredict assistant powered by Gemini 1.5. ${selectedMode !== "general" ? `I'm currently in ${selectedMode} mode. ` : ""}How can I assist you with your churn prediction needs today?`;
      } else if (lowercaseInput.includes("data") || lowercaseInput.includes("upload")) {
        botResponse = "Using our Gemini 1.5 system, you can upload your data in CSV or Excel format on our data upload page. We support various customer datasets with attributes like tenure, spending, and behavior patterns.";
      } else if (lowercaseInput.includes("predict") || lowercaseInput.includes("prediction") || lowercaseInput.includes("churn")) {
        if (selectedMode === "telecom") {
          botResponse = "Our Gemini 1.5 telecom mode analyzes factors like call drops, data usage patterns, and contract length to predict which customers are at risk of switching providers. For telecom clients, we typically achieve 92% prediction accuracy.";
        } else if (selectedMode === "retail") {
          botResponse = "In retail mode, Gemini 1.5 focuses on purchase frequency, basket size, and seasonal buying patterns to identify at-risk customers. We can help you understand which product categories are most likely to retain customers.";
        } else if (selectedMode === "ecommerce") {
          botResponse = "For e-commerce, our Gemini 1.5 analysis tracks website engagement, cart abandonment, and purchase behaviors to forecast churn. We can help you optimize your digital customer journey to improve retention.";
        } else {
          botResponse = "Our Gemini 1.5 algorithm analyzes your customer data to identify those at risk of churning. We examine key factors like tenure, spending patterns, and engagement metrics to provide actionable insights with up to 90% accuracy.";
        }
      } else if (lowercaseInput.includes("algorithm") || lowercaseInput.includes("model")) {
        botResponse = "We use Gemini 1.5, Google's advanced multimodal AI that excels at churn prediction. It's trained on extensive telecom, e-commerce, and retail datasets to recognize churn patterns across industries.";
      } else if (lowercaseInput.includes("help") || lowercaseInput.includes("support")) {
        botResponse = "I can help you understand our Gemini 1.5-powered churn prediction service, guide you through data upload, or explain your analysis results. What specific assistance do you need?";
      } else if (lowercaseInput.includes("price") || lowercaseInput.includes("pricing") || lowercaseInput.includes("cost")) {
        botResponse = "We offer a free trial with basic analysis. Our premium subscription provides in-depth insights, customer segmentation, and actionable retention strategies. Our basic plan starts at ₹9,999 per month, while our premium plan is ₹24,999 per month.";
      } else if (lowercaseInput.includes("faq") || lowercaseInput.includes("question") || lowercaseInput.includes("frequently")) {
        botResponse = "You can view our frequently asked questions by clicking on the FAQ tab above this chat. It covers topics like data formats, pricing, prediction accuracy, and more.";
      } else if (lowercaseInput.includes("gemini") || lowercaseInput.includes("ai")) {
        botResponse = "Our platform uses Gemini 1.5, Google's advanced AI model with 1.5 trillion parameters, to power our churn prediction analytics. This provides enhanced accuracy and deeper insights into customer behavior patterns.";
      } else if (lowercaseInput.includes("export") || lowercaseInput.includes("download") || lowercaseInput.includes("pdf") || lowercaseInput.includes("excel")) {
        botResponse = "Premium users can export analysis results in both PDF and Excel formats. The exports include visualizations, metrics, and recommended actions. You can also export your datasets in Excel format for further analysis.";
      } else if (lowercaseInput.includes("india") || lowercaseInput.includes("indian")) {
        botResponse = "BizPredict is optimized for the Indian market with pricing in rupees and special features for sectors like telecom, retail, and e-commerce that are dominant in India. Our Gemini 1.5 model is trained on data relevant to Indian consumer behavior.";
      } else if (lowercaseInput.includes("compare") || lowercaseInput.includes("difference")) {
        botResponse = "Compared to other solutions, our Gemini 1.5-powered platform offers higher accuracy (85-90%), more actionable insights, and customized retention strategies specifically for your business. Plus, our pricing is competitive for the Indian market.";
      } else if (lowercaseInput.includes("search")) {
        botResponse = "You can use the search feature in the top navigation bar. Just click on the search icon or the search bar, type what you're looking for, and you'll get quick access to analyses, datasets, settings, and more.";
      } else if (lowercaseInput.includes("voice") || lowercaseInput.includes("speak")) {
        botResponse = "You can use voice commands with our Gemini 1.5 chatbot. Click the microphone icon at the bottom of the chat to start speaking. I'll convert your speech to text and respond accordingly. Voice features are enhanced for Premium users.";
      } else if (lowercaseInput.includes("language") || lowercaseInput.includes("hindi") || lowercaseInput.includes("multilingual")) {
        botResponse = "Our Gemini 1.5 assistant supports multiple languages including English, Hindi, Spanish, French, German, Japanese and Chinese. You can select your preferred language from the language dropdown in the chatbot settings.";
      } else if (lowercaseInput.includes("image") || lowercaseInput.includes("picture") || lowercaseInput.includes("graph") || lowercaseInput.includes("chart")) {
        botResponse = "You can upload images of your data visualizations, charts, or graphs and I'll analyze them. Click the image icon at the bottom of the chat to upload. Gemini 1.5 can extract insights from your visuals and provide recommendations.";
      } else if (lowercaseInput.includes("knowledge base") || lowercaseInput.includes("connect") || lowercaseInput.includes("integration")) {
        botResponse = "Premium users can connect Gemini 1.5 to their existing knowledge bases and business data. This allows me to provide more contextually relevant insights based on your specific business information and historical data.";
      } else if (lowercaseInput.includes("industry") || lowercaseInput.includes("specific") || lowercaseInput.includes("telecom") || lowercaseInput.includes("retail")) {
        botResponse = "You can select industry-specific modes for more targeted analysis. We offer specialized modes for telecom, retail, e-commerce, SaaS, and banking sectors. Each mode applies industry-specific insights and benchmarks to your data.";
      } else {
        botResponse = "Thanks for your message. Our Gemini 1.5-powered system is constantly improving our churn prediction algorithms. Is there something specific about customer retention analysis you'd like to know?";
      }

      const botMessageObj: Message = {
        id: (Date.now() + 1).toString(),
        content: botResponse,
        sender: "bot",
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, botMessageObj]);
      setIsProcessing(false);
    }, 1500);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Start voice recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = handleAudioStop;
      mediaRecorder.start();
      setIsRecording(true);
      toast.info("Voice recording started. Speak your question...");
    } catch (error) {
      console.error('Error starting voice recording:', error);
      toast.error('Could not access microphone');
    }
  };

  // Stop voice recording
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  // Handle recorded audio
  const handleAudioStop = async () => {
    setIsProcessing(true);
    
    try {
      const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
      
      // In a real app, this would send the audio to a speech-to-text API
      // Simulate a voice transcription
      const mockVoiceCommands = [
        "Show me the latest churn predictions for high-value customers",
        "What are the main reasons for customer churn in the telecom sector?",
        "How can I reduce churn rate in my e-commerce business?",
        "What's the average customer lifetime value in the retail industry?",
        "How do I connect my CRM system to your platform?"
      ];
      
      const randomCommand = mockVoiceCommands[Math.floor(Math.random() * mockVoiceCommands.length)];
      
      setTimeout(() => {
        // Add transcribed voice as user message
        const userMessage: Message = {
          id: Date.now().toString(),
          content: `🎤 ${randomCommand}`,
          sender: "user",
          timestamp: new Date(),
        };
        
        setMessages(prev => [...prev, userMessage]);
        setInput("");
        
        // Generate bot response based on transcribed voice
        setTimeout(() => {
          let botResponse = "";
          
          if (randomCommand.includes("churn predictions")) {
            botResponse = "Based on your most recent data, high-value customers have a churn risk of 4.2%, which is lower than your overall churn rate of 12.6%. The main risk factors for this segment are competitive offers and service quality issues.";
          } else if (randomCommand.includes("telecom")) {
            botResponse = "In the telecom sector, the primary reasons for churn are: 1) Better pricing from competitors (38%), 2) Network quality issues (24%), 3) Poor customer service experiences (18%), 4) End of contract periods (12%), and 5) Device upgrade opportunities elsewhere (8%).";
          } else if (randomCommand.includes("e-commerce")) {
            botResponse = "To reduce churn in e-commerce, focus on: 1) Personalized product recommendations, 2) Loyalty programs with tangible benefits, 3) Simplified checkout processes, 4) Proactive customer service, and 5) Re-engagement campaigns for inactive customers.";
          } else if (randomCommand.includes("lifetime value")) {
            botResponse = "The average customer lifetime value in the retail industry is approximately ₹42,000. However, this varies significantly by segment - luxury retailers see values of ₹120,000+, while budget retailers average around ₹15,000-25,000.";
          } else if (randomCommand.includes("CRM")) {
            botResponse = "Premium users can connect their CRM systems using our API integration. We support major CRM platforms including Salesforce, HubSpot, and Zoho. This allows Gemini 1.5 to analyze your customer interaction history for more accurate predictions.";
          }
          
          const botMessageObj: Message = {
            id: (Date.now() + 1).toString(),
            content: botResponse,
            sender: "bot",
            timestamp: new Date(),
          };
          
          setMessages(prev => [...prev, botMessageObj]);
          setIsProcessing(false);
        }, 1000);
      }, 1500);
      
      // Clean up the media stream
      if (mediaRecorderRef.current && mediaRecorderRef.current.stream) {
        mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      }
    } catch (error) {
      console.error('Error processing audio:', error);
      setIsProcessing(false);
      toast.error('Failed to process voice input');
    }
  };

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setIsProcessing(true);
    
    // In a real app, this would send the image to a vision API
    // Simulate image analysis
    setTimeout(() => {
      // Add image upload as user message
      const userMessage: Message = {
        id: Date.now().toString(),
        content: `📊 Uploaded a chart: ${file.name}`,
        sender: "user",
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, userMessage]);
      
      // Generate bot response for the image
      setTimeout(() => {
        const botResponse = "I've analyzed your chart and detected a declining trend in customer engagement over Q3, particularly in the mobile app usage segment. This correlates with a 14% increase in churn risk. I recommend focusing on app user experience improvements and implementing push notification re-engagement campaigns.";
        
        const botMessageObj: Message = {
          id: (Date.now() + 1).toString(),
          content: botResponse,
          sender: "bot",
          timestamp: new Date(),
        };
        
        setMessages(prev => [...prev, botMessageObj]);
        setIsProcessing(false);
        setShowImageUploader(false);
      }, 1000);
    }, 1500);
  };

  // Toggle image uploader
  const toggleImageUploader = () => {
    setShowImageUploader(!showImageUploader);
    if (!showImageUploader && fileInputRef.current) {
      // Slight delay to ensure the ref is ready
      setTimeout(() => {
        fileInputRef.current?.click();
      }, 100);
    }
  };

  // Change language handler
  const handleLanguageChange = (language: string) => {
    setSelectedLanguage(language);
    toast.info(`Language changed to ${supportedLanguages.find(l => l.code === language)?.name}`);
    
    // In a real app, this would change the language of the chatbot
    const welcomeMessages = {
      en: "Language set to English. How can I help you today?",
      hi: "भाषा हिंदी पर सेट की गई। मैं आपकी कैसे सहायता कर सकता हूं?",
      es: "Idioma configurado en español. ¿Cómo puedo ayudarte hoy?",
      fr: "Langue définie sur le français. Comment puis-je vous aider aujourd'hui?",
      de: "Sprache auf Deutsch eingestellt. Wie kann ich Ihnen heute helfen?",
      ja: "言語が日本語に設定されました。今日はどのようにお手伝いできますか？",
      zh: "语言设置为中文。今天我能帮您什么忙？"
    };
    
    const languageMessage: Message = {
      id: Date.now().toString(),
      content: welcomeMessages[language as keyof typeof welcomeMessages] || welcomeMessages.en,
      sender: "bot",
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, languageMessage]);
  };

  // Change industry mode handler
  const handleModeChange = (mode: string) => {
    setSelectedMode(mode);
    
    const modeName = industryModes.find(m => m.id === mode)?.name || "General";
    toast.info(`Analysis mode changed to ${modeName}`);
    
    const modeMessage: Message = {
      id: Date.now().toString(),
      content: `I've switched to ${modeName} analysis mode. My responses will now be tailored to ${modeName.toLowerCase()} industry patterns and benchmarks.`,
      sender: "bot",
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, modeMessage]);
  };

  // Filter FAQ items based on search
  useEffect(() => {
    if (!searchQuery) {
      setFilteredFaq(faqItems);
    } else {
      const filtered = faqItems.filter(
        item => 
          item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.answer.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredFaq(filtered);
    }
  }, [searchQuery]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const positionClasses = position === "bottom-right" ? "bottom-6 right-6" : "bottom-6 right-6";

  return (
    <div className={`fixed ${positionClasses} z-50`}>
      {!isOpen ? (
        <Button
          onClick={() => setIsOpen(true)}
          className="h-14 w-14 rounded-full shadow-lg bg-primary hover:bg-primary/90"
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
      ) : (
        <Card className="w-80 h-96 shadow-xl">
          <CardHeader className="bg-primary text-white p-4 flex flex-row justify-between items-center">
            <div className="flex items-center">
              <MessageCircle className="h-5 w-5 mr-2" />
              <h3 className="font-medium text-sm">BizPredict Assistant (Gemini 1.5)</h3>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-white hover:text-white/80 hover:bg-primary-foreground/20"
              onClick={() => setIsOpen(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          <Tabs 
            value={activeTab} 
            onValueChange={setActiveTab} 
            className="h-[calc(100%-60px)]"
          >
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="chat">Chat</TabsTrigger>
              <TabsTrigger value="faq">FAQ</TabsTrigger>
            </TabsList>
            <TabsContent value="chat" className="h-[calc(100%-40px)]">
              {/* Settings Bar */}
              <div className="p-2 border-b flex justify-between items-center">
                <Select 
                  value={selectedLanguage} 
                  onValueChange={handleLanguageChange}
                >
                  <SelectTrigger className="w-24 h-7 text-xs">
                    <Globe className="h-3 w-3 mr-1" />
                    <SelectValue placeholder="Language" />
                  </SelectTrigger>
                  <SelectContent>
                    {supportedLanguages.map(lang => (
                      <SelectItem key={lang.code} value={lang.code} className="text-xs">
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Select 
                  value={selectedMode} 
                  onValueChange={handleModeChange}
                >
                  <SelectTrigger className="w-24 h-7 text-xs">
                    <Zap className="h-3 w-3 mr-1" />
                    <SelectValue placeholder="Mode" />
                  </SelectTrigger>
                  <SelectContent>
                    {industryModes.map(mode => (
                      <SelectItem key={mode.id} value={mode.id} className="text-xs">
                        {mode.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <CardContent className="p-0 h-[calc(100%-96px)]">
                <ScrollArea className="h-full p-4">
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${
                          message.sender === "user" ? "justify-end" : "justify-start"
                        }`}
                      >
                        <div
                          className={`max-w-[80%] rounded-lg p-3 ${
                            message.sender === "user"
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted"
                          }`}
                        >
                          <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                          <p className="text-xs opacity-70 mt-1">
                            {message.timestamp.toLocaleTimeString([], { 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            })}
                          </p>
                        </div>
                      </div>
                    ))}
                    {isProcessing && (
                      <div className="flex justify-start">
                        <div className="max-w-[80%] rounded-lg p-3 bg-muted">
                          <div className="flex space-x-1 items-center">
                            <div className="h-2 w-2 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                            <div className="h-2 w-2 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                            <div className="h-2 w-2 bg-slate-400 rounded-full animate-bounce"></div>
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>
              </CardContent>
              <CardFooter className="p-3 pt-2 border-t">
                <div className="flex w-full items-center space-x-2">
                  <Input
                    placeholder="Type a message..."
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    className="flex-1"
                    disabled={isProcessing}
                  />
                  <Button 
                    size="icon" 
                    variant="ghost"
                    onClick={() => {
                      if (isRecording) {
                        stopRecording();
                      } else {
                        startRecording();
                      }
                    }}
                    className={isRecording ? "text-red-500" : ""}
                    disabled={isProcessing}
                  >
                    <Mic className="h-4 w-4" />
                  </Button>
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handleImageUpload}
                    style={{ display: 'none' }}
                  />
                  <Button 
                    size="icon" 
                    variant="ghost"
                    onClick={toggleImageUploader}
                    disabled={isProcessing}
                  >
                    <Image className="h-4 w-4" />
                  </Button>
                  <Button 
                    size="icon" 
                    onClick={handleSendMessage} 
                    disabled={!input.trim() || isProcessing}
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardFooter>
            </TabsContent>
            <TabsContent value="faq" className="h-[calc(100%-40px)]">
              <CardContent className="p-0 h-full">
                <div className="p-3 border-b">
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input 
                      placeholder="Search FAQs..." 
                      className="pl-8"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <ScrollArea className="h-[calc(100%-56px)] p-4">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2 mb-4">
                      <HelpCircle className="h-5 w-5 text-primary" />
                      <h3 className="font-medium">Frequently Asked Questions</h3>
                    </div>
                    {filteredFaq.length > 0 ? (
                      filteredFaq.map((item, index) => (
                        <div key={index} className="space-y-1">
                          <h4 className="font-medium text-sm">{item.question}</h4>
                          <p className="text-sm text-muted-foreground">{item.answer}</p>
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">No FAQs match your search. Try a different query.</p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </TabsContent>
          </Tabs>
        </Card>
      )}
    </div>
  );
}

export default Chatbot;
