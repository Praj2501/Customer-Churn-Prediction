import { useEffect, useState } from "react";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { cn } from "@/lib/utils";

export type ChartType = "area" | "bar" | "pie";

interface ChartPreviewProps {
  type?: ChartType;
  data?: any[];
  colors?: string[];
  className?: string;
  height?: number;
  showLegend?: boolean;
  showGrid?: boolean;
  animate?: boolean;
  xKey?: string;
  dataKey?: string;
  nameKey?: string;
  formatter?: (value: any) => string;
  series?: Array<{
    name: string;
    dataKey: string;
    color?: string;
  }>;
}

export function ChartPreview({
  type = "area",
  data: externalData,
  colors = ["#3b82f6", "#60a5fa", "#93c5fd"],
  className,
  height = 300,
  showLegend = false,
  showGrid = true,
  animate = true,
  xKey = "name",
  dataKey = "value",
  nameKey = "name",
  formatter,
  series
}: ChartPreviewProps) {
  const [data, setData] = useState<any[]>([]);
  
  const areaData = [
    { name: "Jan", value: 40 },
    { name: "Feb", value: 30 },
    { name: "Mar", value: 20 },
    { name: "Apr", value: 27 },
    { name: "May", value: 45 },
    { name: "Jun", value: 55 },
    { name: "Jul", value: 65 },
    { name: "Aug", value: 60 },
    { name: "Sep", value: 70 },
    { name: "Oct", value: 55 },
    { name: "Nov", value: 50 },
    { name: "Dec", value: 60 },
  ];

  const barData = [
    { name: "Low Risk", value: 65 },
    { name: "Medium Risk", value: 30 },
    { name: "High Risk", value: 15 },
  ];

  const pieData = [
    { name: "Healthy", value: 60 },
    { name: "At Risk", value: 25 },
    { name: "Critical", value: 15 },
  ];

  useEffect(() => {
    if (externalData) {
      setData(externalData);
    } else {
      if (type === "area") setData(areaData);
      else if (type === "bar") setData(barData);
      else if (type === "pie") setData(pieData);
    }
  }, [externalData, type]);

  useEffect(() => {
    if (!animate) return;
    
    const interval = setInterval(() => {
      if (type === "area") {
        setData(prev => 
          prev.map(item => ({
            ...item,
            value: item.value + (Math.random() * 10 - 5)
          }))
        );
      }
    }, 3000);
    
    return () => clearInterval(interval);
  }, [animate, type]);

  const exportChart = () => {
    const chartElement = document.querySelector(`.chart-container-${type}`) as HTMLElement;
    if (!chartElement) return;

    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    
    if (!context) return;
    
    const width = chartElement.offsetWidth;
    const height = chartElement.offsetHeight;
    
    canvas.width = width;
    canvas.height = height;
    
    const svgData = new XMLSerializer().serializeToString(chartElement.querySelector('svg') as SVGElement);
    
    const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    
    const url = URL.createObjectURL(svgBlob);
    
    const img = new Image();
    img.onload = () => {
      context.drawImage(img, 0, 0);
      
      const dataUrl = canvas.toDataURL('image/png');
      
      const downloadLink = document.createElement('a');
      downloadLink.href = dataUrl;
      downloadLink.download = `chart-${type}-${new Date().toISOString().slice(0, 10)}.png`;
      
      downloadLink.click();
      
      URL.revokeObjectURL(url);
    };
    
    img.src = url;
  };

  const renderChart = () => {
    switch (type) {
      case "area":
        return (
          <ResponsiveContainer width="100%" height={height} className={`chart-container-${type}`}>
            <AreaChart data={data} margin={{ top: 10, right: 0, left: 0, bottom: 0 }}>
              {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />}
              <XAxis 
                dataKey={xKey} 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#94a3b8', fontSize: 12 }}
                dy={10}
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#94a3b8', fontSize: 12 }}
                dx={-10}
                tickFormatter={formatter}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  borderRadius: '0.75rem',
                  border: '1px solid #e2e8f0',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)'
                }}
                formatter={formatter}
              />
              {series ? (
                series.map((s, index) => (
                  <Area 
                    key={s.name}
                    type="monotone" 
                    dataKey={s.dataKey} 
                    stroke={s.color || colors[index % colors.length]} 
                    strokeWidth={2}
                    fillOpacity={0.7} 
                    fill={`url(#color${s.name})`} 
                  />
                ))
              ) : (
                <>
                  <defs>
                    <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={colors[0]} stopOpacity={0.8}/>
                      <stop offset="95%" stopColor={colors[0]} stopOpacity={0.1}/>
                    </linearGradient>
                  </defs>
                  <Area 
                    type="monotone" 
                    dataKey={dataKey} 
                    stroke={colors[0]} 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorValue)" 
                  />
                </>
              )}
            </AreaChart>
          </ResponsiveContainer>
        );

      case "bar":
        return (
          <ResponsiveContainer width="100%" height={height} className={`chart-container-${type}`}>
            <BarChart data={data} margin={{ top: 10, right: 0, left: 0, bottom: 0 }}>
              {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />}
              <XAxis 
                dataKey={xKey} 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#94a3b8', fontSize: 12 }}
                dy={10}
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#94a3b8', fontSize: 12 }}
                dx={-10}
                tickFormatter={formatter}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  borderRadius: '0.75rem',
                  border: '1px solid #e2e8f0',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)'
                }}
                formatter={formatter}
              />
              {series ? (
                series.map((s, index) => (
                  <Bar 
                    key={s.name}
                    dataKey={s.dataKey} 
                    radius={[4, 4, 0, 0]} 
                    barSize={40}
                    fill={s.color || colors[index % colors.length]}
                  />
                ))
              ) : (
                <Bar 
                  dataKey={dataKey} 
                  radius={[4, 4, 0, 0]} 
                  barSize={40}
                >
                  {data.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={colors[index % colors.length]} 
                    />
                  ))}
                </Bar>
              )}
            </BarChart>
          </ResponsiveContainer>
        );

      case "pie":
        return (
          <ResponsiveContainer width="100%" height={height} className={`chart-container-${type}`}>
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey={dataKey}
                nameKey={nameKey}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                labelLine={false}
              >
                {data.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={colors && colors[index] ? colors[index] : colors[index % colors.length]} 
                  />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  borderRadius: '0.75rem',
                  border: '1px solid #e2e8f0',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)'
                }}
                formatter={formatter}
              />
            </PieChart>
          </ResponsiveContainer>
        );
        
      default:
        return null;
    }
  };

  return (
    <div className={cn("rounded-xl bg-white border border-slate-200/70 shadow-sm overflow-hidden", className)}>
      <div className="p-4">
        {renderChart()}
        <div className="flex justify-end mt-3">
          <button 
            onClick={exportChart}
            className="text-xs text-slate-500 hover:text-slate-700 flex items-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Save Image
          </button>
        </div>
      </div>
    </div>
  );
}

export default ChartPreview;
