
import React, { useState } from 'react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { useNavigate } from "react-router-dom";

interface SearchResult {
  id: string;
  title: string;
  description: string;
  route: string;
}

// Mock search results - in a real app, these would come from a search API
const mockResults: SearchResult[] = [
  {
    id: "1",
    title: "Customer Churn Analysis",
    description: "View predictions and insights on customer churn patterns",
    route: "/dashboard",
  },
  {
    id: "2",
    title: "Upload New Dataset",
    description: "Upload CSV or Excel files for analysis",
    route: "/data-upload",
  },
  {
    id: "3",
    title: "Telecom Q2 Analysis",
    description: "Detailed churn report for telecom customers",
    route: "/analysis-results/a1b2c3d4",
  },
  {
    id: "4",
    title: "E-commerce Analysis",
    description: "Shopper behavior and retention insights",
    route: "/analysis-results/e5f6g7h8",
  },
  {
    id: "5",
    title: "Account Settings",
    description: "Manage your account and preferences",
    route: "/settings",
  },
];

export function SearchBar() {
  const [open, setOpen] = useState(false);
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const navigate = useNavigate();

  // Mock search function - in a real app, this would query a search API
  const handleSearch = (searchTerm: string) => {
    if (!searchTerm.trim()) {
      setSearchResults([]);
      return;
    }
    
    const filtered = mockResults.filter(
      result => 
        result.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        result.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    setSearchResults(filtered);
  };

  const handleResultClick = (route: string) => {
    setOpen(false);
    navigate(route);
  };

  return (
    <>
      <Button
        variant="outline"
        className="relative h-9 w-full justify-start rounded-[0.5rem] bg-background text-sm font-normal text-muted-foreground shadow-none sm:pr-12 md:w-40 lg:w-64"
        onClick={() => setOpen(true)}
      >
        <span className="hidden lg:inline-flex">Search BizPredict...</span>
        <span className="inline-flex lg:hidden">Search...</span>
        <Search className="ml-auto h-4 w-4 opacity-50" />
      </Button>
      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput 
          placeholder="Search for analyses, datasets, settings..." 
          onValueChange={handleSearch}
        />
        <CommandList>
          <CommandEmpty>No results found.</CommandEmpty>
          <CommandGroup heading="Results">
            {searchResults.map((result) => (
              <CommandItem 
                key={result.id}
                onSelect={() => handleResultClick(result.route)}
              >
                <div className="flex flex-col">
                  <span>{result.title}</span>
                  <span className="text-xs text-muted-foreground">{result.description}</span>
                </div>
              </CommandItem>
            ))}
          </CommandGroup>
        </CommandList>
      </CommandDialog>
    </>
  );
}

export default SearchBar;
