
import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface FeatureCardProps {
  title: string;
  description: string;
  icon?: ReactNode;
  className?: string;
  iconClassName?: string;
  index?: number;
}

export function FeatureCard({
  title,
  description,
  icon,
  className,
  iconClassName,
  index = 0
}: FeatureCardProps) {
  return (
    <div 
      className={cn(
        "group glass-panel p-6 hover:shadow-md transition-all duration-300 animate-on-scroll", 
        className,
        index === 0 ? "delay-100" : "",
        index === 1 ? "delay-200" : "",
        index === 2 ? "delay-300" : "",
        index === 3 ? "delay-400" : "",
        index >= 4 ? "delay-500" : "",
      )}
    >
      {icon && (
        <div className={cn(
          "mb-4 w-12 h-12 flex items-center justify-center rounded-full bg-primary/10 text-primary group-hover:scale-110 transition-transform duration-300", 
          iconClassName
        )}>
          {icon}
        </div>
      )}
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-slate-500 text-sm leading-relaxed">{description}</p>
    </div>
  );
}

export default FeatureCard;
