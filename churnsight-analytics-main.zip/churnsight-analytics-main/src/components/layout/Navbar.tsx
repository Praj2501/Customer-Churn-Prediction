
import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/App';
import { ProfileMenu } from '@/components/layout/ProfileMenu';
import { ScheduleDemo } from '@/components/modals/ScheduleDemo';

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showDemoModal, setShowDemoModal] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogin = () => {
    navigate('/login');
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleScheduleDemo = () => {
    if (isAuthenticated) {
      setShowDemoModal(true);
    } else {
      navigate('/login');
    }
  };

  return (
    <header
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out px-6 lg:px-10',
        isScrolled 
          ? 'py-3 bg-white/80 backdrop-blur-md shadow-sm' 
          : 'py-5 bg-transparent'
      )}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <div className="relative h-8 w-8 rounded-full bg-gradient-to-tr from-blue-600 to-blue-400 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-white/20 backdrop-blur-sm opacity-50"></div>
            <span className="text-white font-display font-bold text-lg">B</span>
          </div>
          <span className="font-display font-bold text-xl">BizPredict</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <a href="/#features" className="text-sm font-medium hover:text-primary transition-colors">
            Features
          </a>
          <a href="/#dashboard" className="text-sm font-medium hover:text-primary transition-colors">
            Overview
          </a>
          <a href="/#health-score" className="text-sm font-medium hover:text-primary transition-colors">
            Health Score
          </a>
          {isAuthenticated && (
            <Link to="/data-upload" className="text-sm font-medium hover:text-primary transition-colors">
              Upload Data
            </Link>
          )}
          <a
            onClick={handleScheduleDemo}
            className="text-sm font-medium hover:text-primary transition-colors cursor-pointer"
          >
            Schedule Demo
          </a>
          <a href="/#contact" className="text-sm font-medium hover:text-primary transition-colors">
            Contact
          </a>
        </nav>

        <div className="hidden md:flex items-center space-x-4">
          {isAuthenticated ? (
            <div className="flex items-center space-x-4">
              <ProfileMenu />
            </div>
          ) : (
            <>
              <Button 
                variant="outline" 
                size="sm" 
                className="rounded-full px-4"
                onClick={handleLogin}
              >
                Log In
              </Button>
              <Link to="/signup">
                <Button size="sm" className="rounded-full px-4">
                  Get Started
                </Button>
              </Link>
            </>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden flex items-center"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle menu"
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor" 
            className="w-6 h-6"
          >
            {isMobileMenuOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white/95 backdrop-blur-lg shadow-lg border-t border-slate-200/50 animate-fade-in">
          <div className="px-6 py-4 flex flex-col space-y-4">
            <a 
              href="/#features" 
              className="text-sm font-medium py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Features
            </a>
            <a 
              href="/#dashboard" 
              className="text-sm font-medium py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Overview
            </a>
            <a 
              href="/#health-score" 
              className="text-sm font-medium py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Health Score
            </a>
            {isAuthenticated && (
              <Link 
                to="/data-upload" 
                className="text-sm font-medium py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Upload Data
              </Link>
            )}
            <a 
              className="text-sm font-medium py-2 cursor-pointer"
              onClick={() => {
                setIsMobileMenuOpen(false);
                handleScheduleDemo();
              }}
            >
              Schedule Demo
            </a>
            <a 
              href="/#contact" 
              className="text-sm font-medium py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Contact
            </a>
            {isAuthenticated ? (
              <div className="flex flex-col space-y-2 pt-2">
                <Link 
                  to="/dashboard"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Button variant="outline" size="sm" className="rounded-full w-full">
                    Dashboard
                  </Button>
                </Link>
                <Link 
                  to="/admin-dashboard"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Button variant="outline" size="sm" className="rounded-full w-full">
                    Admin Dashboard
                  </Button>
                </Link>
                <Button 
                  size="sm" 
                  className="rounded-full w-full"
                  onClick={() => {
                    handleLogout();
                    setIsMobileMenuOpen(false);
                  }}
                >
                  Log Out
                </Button>
              </div>
            ) : (
              <div className="flex flex-col space-y-2 pt-2">
                <Link 
                  to="/login"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Button variant="outline" size="sm" className="rounded-full w-full">
                    Log In
                  </Button>
                </Link>
                <Link 
                  to="/signup"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Button size="sm" className="rounded-full w-full">
                    Get Started
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
      <ScheduleDemo open={showDemoModal} onOpenChange={setShowDemoModal} />
    </header>
  );
}

export default Navbar;
