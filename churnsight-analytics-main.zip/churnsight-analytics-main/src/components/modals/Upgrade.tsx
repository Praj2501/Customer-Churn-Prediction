
import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { formatIndianRupees } from "@/utils/formatters";
import { useAuth } from '@/App';

export interface UpgradeProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function Upgrade({ open, onOpenChange }: UpgradeProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [plan, setPlan] = useState("monthly");
  const [isProcessing, setIsProcessing] = useState(false);

  const handleUpgrade = () => {
    setIsProcessing(true);
    
    // Simulate API call to upgrade account
    setTimeout(() => {
      setIsProcessing(false);
      onOpenChange(false);
      
      toast({
        title: "Upgrade Successful!",
        description: `You've been upgraded to Premium. Enjoy all the advanced features.`,
      });
    }, 1500);
  };

  // Reduced pricing structure
  const plans = {
    basic: {
      monthly: 4999,
      annual: 49999
    },
    premium: {
      monthly: 9999,
      annual: 99999
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Upgrade to Premium</DialogTitle>
          <DialogDescription>
            Unlock advanced features and unlimited analysis with our premium plans
          </DialogDescription>
        </DialogHeader>
        
        <div className="mt-4 space-y-4">
          <RadioGroup value={plan} onValueChange={setPlan} className="flex flex-col gap-4">
            <div className="flex items-start">
              <RadioGroupItem value="monthly" id="monthly" />
              <div className="ml-3 flex-1">
                <Label htmlFor="monthly" className="font-medium">Monthly Billing</Label>
                <p className="text-sm text-slate-500 mt-1">Pay monthly, cancel anytime</p>
              </div>
              <div className="text-right">
                <div className="font-medium">{formatIndianRupees(plans.premium.monthly)}</div>
                <div className="text-xs text-slate-500">per month</div>
              </div>
            </div>
            
            <div className="flex items-start">
              <RadioGroupItem value="annual" id="annual" />
              <div className="ml-3 flex-1">
                <Label htmlFor="annual" className="font-medium">Annual Billing</Label>
                <p className="text-sm text-slate-500 mt-1">Pay yearly (17% off)</p>
              </div>
              <div className="text-right">
                <div className="font-medium">{formatIndianRupees(plans.premium.annual / 12)}</div>
                <div className="text-xs text-slate-500">per month</div>
              </div>
            </div>
          </RadioGroup>
          
          <div className="bg-slate-50 rounded-lg p-4 mt-6">
            <h4 className="font-medium mb-2">Premium Features</h4>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Unlimited data analysis
              </li>
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Advanced XGBoost predictions
              </li>
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Customizable retention strategies
              </li>
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                24/7 priority support
              </li>
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Interactive heatmaps & benchmarking
              </li>
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Voice & image analysis capabilities
              </li>
            </ul>
          </div>
        </div>
        
        <DialogFooter className="mt-6">
          <Button onClick={handleUpgrade} disabled={isProcessing} className="w-full">
            {isProcessing ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
              </>
            ) : (
              `Upgrade Now - ${plan === "monthly" ? formatIndianRupees(plans.premium.monthly) : formatIndianRupees(plans.premium.annual)} ${plan === "monthly" ? "/month" : "/year"}`
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default Upgrade;
