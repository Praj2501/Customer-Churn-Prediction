
import { Button } from '@/components/ui/button';
import { ChartPreview } from '../ui/ChartPreview';
import { AnimatedNumber } from '../ui/AnimatedNumber';
import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { DatePickerWithRange } from '../ui/DateRangePicker';
import { addDays } from 'date-fns';
import { toast } from '@/hooks/use-toast';

export function Dashboard() {
  const [isVisible, setIsVisible] = useState(false);
  const navigate = useNavigate();
  const [selectedSegment, setSelectedSegment] = useState('all');
  const [showBenchmark, setShowBenchmark] = useState(false);
  const [date, setDate] = useState({
    from: addDays(new Date(), -30),
    to: new Date(),
  });
  
  // Voice recognition setup
  const recognition = useRef(null);
  const [isListening, setIsListening] = useState(false);
  const [voiceInput, setVoiceInput] = useState('');
  
  useEffect(() => {
    try {
      // @ts-ignore - SpeechRecognition is not in TypeScript types yet
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        recognition.current = new SpeechRecognition();
        recognition.current.continuous = true;
        recognition.current.interimResults = true;
        
        recognition.current.onresult = (event) => {
          const transcript = Array.from(event.results)
            .map(result => result[0])
            .map(result => result.transcript)
            .join('');
          
          setVoiceInput(transcript);
          
          // Simple command handling
          if (transcript.toLowerCase().includes('show benchmark')) {
            setShowBenchmark(true);
          } else if (transcript.toLowerCase().includes('hide benchmark')) {
            setShowBenchmark(false);
          }
        };
        
        recognition.current.onerror = (event) => {
          console.error('Speech recognition error', event.error);
          setIsListening(false);
        };
      }
    } catch (error) {
      console.error('Speech recognition not supported', error);
    }
  }, []);
  
  // Handle voice activation
  const toggleListening = () => {
    if (isListening) {
      recognition.current?.stop();
      setIsListening(false);
    } else {
      recognition.current?.start();
      setIsListening(true);
      toast.info('Voice recognition activated. Try saying "Show benchmark" or "Hide benchmark"');
    }
  };
  
  // Handle image upload for data analysis
  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      toast.info('Image uploaded. AI analysis in progress...');
      // This would connect to an AI service to analyze the chart/image
      setTimeout(() => {
        toast.success('Image analysis complete. Data extracted and insights generated.');
      }, 3000);
    }
  };
  
  const goToDashboard = () => {
    navigate('/dashboard');
  };
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    const element = document.getElementById('dashboard-section');
    if (element) {
      observer.observe(element);
    }

    return () => {
      if (element) {
        observer.unobserve(element);
      }
    };
  }, []);

  return (
    <section id="dashboard" className="section-padding relative overflow-hidden">
      <div id="dashboard-section" className="container max-w-7xl mx-auto px-6 lg:px-10">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          {/* Left content */}
          <div className="w-full lg:w-1/2 lg:pr-6 animate-on-scroll">
            <div className="relative">
              {/* Absolute decorative blob */}
              <div className="absolute -top-10 -left-10 w-40 h-40 bg-blue-400 rounded-full mix-blend-multiply blur-3xl opacity-10"></div>
              
              {/* Dashboard preview */}
              <div className="relative z-10 glass-panel p-4 lg:p-6">
                <div className="mb-6 flex justify-between items-center border-b border-slate-100 pb-4">
                  <h3 className="font-medium text-slate-800">Customer Churn Risk Analysis</h3>
                  <div className="flex space-x-2">
                    <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                    <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  </div>
                </div>
                
                {/* New: Date Range Selector */}
                <div className="mb-4">
                  <DatePickerWithRange
                    date={date}
                    onDateChange={setDate}
                    className="w-full"
                  />
                </div>
                
                {/* New: Segment Selection */}
                <div className="flex mb-4 space-x-2 overflow-x-auto pb-2">
                  {['All Customers', 'High Value', 'At Risk', 'New Users', 'Inactive'].map((segment) => (
                    <Button 
                      key={segment}
                      variant={selectedSegment === segment.toLowerCase() ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedSegment(segment.toLowerCase())}
                      className="whitespace-nowrap text-xs"
                    >
                      {segment}
                    </Button>
                  ))}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-slate-50/50 backdrop-blur-xs rounded-lg p-4 border border-slate-100">
                    <div className="text-sm text-slate-500 mb-1">Churn Rate</div>
                    <div className="text-2xl font-display font-bold text-slate-800">
                      {isVisible && <AnimatedNumber value={4.7} formatter={(v) => `${v}%`} decimals={1} />}
                    </div>
                    <div className="text-xs text-red-500 flex items-center mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-3 h-3 mr-1">
                        <path strokeLinecap="round" strokeLinejoin="round" d="m4.5 15.75 7.5-7.5 7.5 7.5" />
                      </svg>
                      0.3% from last month
                    </div>
                    
                    {/* Industry Benchmark */}
                    {showBenchmark && (
                      <div className="mt-2 text-xs text-blue-600">
                        Industry benchmark: 5.2%
                      </div>
                    )}
                  </div>
                  <div className="bg-slate-50/50 backdrop-blur-xs rounded-lg p-4 border border-slate-100">
                    <div className="text-sm text-slate-500 mb-1">At-Risk Customers</div>
                    <div className="text-2xl font-display font-bold text-slate-800">
                      {isVisible && <AnimatedNumber value={124} formatter={(v) => `${Math.round(v)}`} />}
                    </div>
                    <div className="text-xs text-amber-500 flex items-center mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-3 h-3 mr-1">
                        <path strokeLinecap="round" strokeLinejoin="round" d="m4.5 15.75 7.5-7.5 7.5 7.5" />
                      </svg>
                      12% from last month
                    </div>
                    
                    {/* Industry Benchmark */}
                    {showBenchmark && (
                      <div className="mt-2 text-xs text-blue-600">
                        Industry benchmark: 8-10%
                      </div>
                    )}
                  </div>
                  <div className="bg-slate-50/50 backdrop-blur-xs rounded-lg p-4 border border-slate-100">
                    <div className="text-sm text-slate-500 mb-1">Retention Rate</div>
                    <div className="text-2xl font-display font-bold text-slate-800">
                      {isVisible && <AnimatedNumber value={95.3} formatter={(v) => `${v}%`} decimals={1} />}
                    </div>
                    <div className="text-xs text-green-500 flex items-center mt-1">
                      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-3 h-3 mr-1">
                        <path strokeLinecap="round" strokeLinejoin="round" d="m4.5 8.25 7.5 7.5 7.5-7.5" />
                      </svg>
                      0.3% from last month
                    </div>
                    
                    {/* Industry Benchmark */}
                    {showBenchmark && (
                      <div className="mt-2 text-xs text-blue-600">
                        Industry benchmark: 94.8%
                      </div>
                    )}
                  </div>
                </div>
                
                {/* New: Engagement Heatmap Toggle */}
                <div className="mb-4">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => toast.info('Interactive heatmap view activated')}
                    className="text-xs mr-2"
                  >
                    View Engagement Heatmap
                  </Button>
                  <Button 
                    variant={showBenchmark ? "default" : "outline"} 
                    size="sm" 
                    onClick={() => setShowBenchmark(!showBenchmark)}
                    className="text-xs"
                  >
                    {showBenchmark ? 'Hide Benchmarks' : 'Show Industry Benchmarks'}
                  </Button>
                </div>
                
                <ChartPreview 
                  type="area" 
                  height={240} 
                  animate={isVisible}
                  colors={['#3b82f6', '#60a5fa', '#93c5fd']}
                  className="mb-6 bg-transparent border-0 shadow-none"
                />
                
                {/* New: Voice Input Display */}
                {voiceInput && (
                  <div className="bg-slate-50 p-3 rounded-lg mb-4 text-sm text-slate-700">
                    <div className="font-medium mb-1">Voice Command:</div>
                    {voiceInput}
                  </div>
                )}
                
                <div className="flex justify-between">
                  <div className="flex items-center space-x-2">
                    {/* Voice Input Button */}
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={toggleListening}
                      className={`text-xs ${isListening ? 'bg-red-50 text-red-600' : ''}`}
                    >
                      {isListening ? 'Stop Listening' : 'Voice Input'}
                      <svg xmlns="http://www.w3.org/2000/svg" className="ml-1 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                      </svg>
                    </Button>
                    
                    {/* Image Upload */}
                    <label className="cursor-pointer">
                      <Button variant="outline" size="sm" className="text-xs" as="div">
                        Upload Chart
                        <svg xmlns="http://www.w3.org/2000/svg" className="ml-1 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                      </Button>
                      <input 
                        type="file" 
                        accept="image/*" 
                        className="hidden" 
                        onChange={handleImageUpload}
                      />
                    </label>
                  </div>
                  
                  <div>
                    <Button variant="outline" size="sm" className="text-xs mr-2">
                      Export Data
                    </Button>
                    <Button size="sm" className="text-xs">
                      View Details
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Right content */}
          <div className="w-full lg:w-1/2 animate-on-scroll delay-200">
            <h2 className="heading-lg text-slate-900 mb-6">
              Powerful Dashboard for Actionable Insights
            </h2>
            <p className="text-slate-600 mb-6">
              Our intuitive dashboard gives you a comprehensive view of customer health, 
              churn risk, and engagement metrics. Monitor trends in real-time and spot 
              potential issues before they lead to customer loss.
            </p>
            <ul className="space-y-4 mb-8">
              {[
                "Visualize customer health scores across your entire customer base",
                "Track churn rates by segment, product, or other custom parameters",
                "Identify patterns and correlations between customer behaviors and churn",
                "Set custom alerts when metrics cross defined thresholds"
              ].map((item, index) => (
                <li key={index} className="flex items-start">
                  <div className="mr-3 mt-1 text-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                    </svg>
                  </div>
                  <span className="text-slate-600">{item}</span>
                </li>
              ))}
            </ul>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="rounded-full px-6" onClick={goToDashboard}>Explore Dashboard</Button>
              <Button variant="outline" className="rounded-full px-6">View Demo</Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Dashboard;
