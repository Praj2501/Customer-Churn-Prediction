
import { ChartPreview } from '../ui/ChartPreview';
import { useState, useEffect } from 'react';

export function HealthScore() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    const element = document.getElementById('health-score-section');
    if (element) {
      observer.observe(element);
    }

    return () => {
      if (element) {
        observer.unobserve(element);
      }
    };
  }, []);

  const pieData = [
    { name: "Healthy", value: 65, color: "#10b981" },
    { name: "At Risk", value: 25, color: "#f59e0b" },
    { name: "Critical", value: 10, color: "#ef4444" },
  ];

  return (
    <section id="health-score" className="section-padding bg-gradient-to-b from-slate-50 to-white relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-40 bg-gradient-to-b from-white to-transparent z-0"></div>
      <div className="absolute bottom-0 right-0 w-1/3 h-1/3 bg-blue-50 rounded-full blur-3xl opacity-30 z-0"></div>
      
      <div id="health-score-section" className="container max-w-7xl mx-auto px-6 lg:px-10 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="heading-lg text-slate-900 mb-4 animate-on-scroll">
            Customer Health Scoring
          </h2>
          <p className="text-slate-600 animate-on-scroll delay-100">
            Monitor the vitality of your customer relationships with our advanced health scoring system. 
            Instantly identify at-risk accounts and take proactive measures.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Health Score Distribution */}
          <div className="lg:col-span-1 animate-on-scroll">
            <div className="glass-panel h-full p-6">
              <h3 className="text-lg font-semibold mb-4">Health Score Distribution</h3>
              <ChartPreview 
                type="pie" 
                height={280}
                colors={pieData.map(item => item.color)} 
                data={pieData}
                animate={isVisible}
              />
              <div className="mt-6 space-y-3">
                {pieData.map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div 
                        className="w-3 h-3 rounded-full mr-2" 
                        style={{ backgroundColor: item.color }}
                      ></div>
                      <span className="text-sm text-slate-700">{item.name}</span>
                    </div>
                    <span className="text-sm font-medium">{item.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Scoring Categories */}
          <div className="lg:col-span-2 animate-on-scroll delay-200">
            <div className="glass-panel h-full p-6">
              <h3 className="text-lg font-semibold mb-6">Health Score Components</h3>
              
              <div className="space-y-8">
                {[
                  {
                    title: "Engagement Score",
                    description: "Measures how actively customers interact with your product, including login frequency, feature usage, and time spent.",
                    score: 85,
                    color: "#10b981"
                  },
                  {
                    title: "Support Interaction",
                    description: "Analyzes the frequency, nature, and resolution of customer support tickets to identify satisfaction issues.",
                    score: 68,
                    color: "#f59e0b"
                  },
                  {
                    title: "Growth Trajectory",
                    description: "Tracks whether a customer's usage is increasing, stable, or declining over time compared to similar accounts.",
                    score: 93,
                    color: "#10b981"
                  }
                ].map((item, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-baseline">
                      <h4 className="font-medium text-slate-800">{item.title}</h4>
                      <div className="flex items-center">
                        <span 
                          className="text-sm font-semibold mr-2" 
                          style={{ color: item.color }}
                        >
                          {item.score}/100
                        </span>
                        <div 
                          className="w-2 h-2 rounded-full" 
                          style={{ backgroundColor: item.color }}
                        ></div>
                      </div>
                    </div>
                    <p className="text-sm text-slate-500">{item.description}</p>
                    <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2">
                      <div 
                        className="h-1.5 rounded-full transition-all duration-1000 ease-out"
                        style={{ 
                          width: isVisible ? `${item.score}%` : '0%',
                          backgroundColor: item.color 
                        }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-8 pt-6 border-t border-slate-100">
                <h4 className="font-medium text-slate-800 mb-4">Custom Health Score Factors</h4>
                <p className="text-sm text-slate-500 mb-4">
                  Our platform allows you to customize health score components based on your business's unique indicators of customer success and risk.
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  {["Product Adoption", "Contract Value", "Renewal Proximity", "Sentiment Analysis"].map((item, index) => (
                    <div 
                      key={index} 
                      className="text-xs bg-slate-50 text-slate-700 rounded-full px-3 py-1.5 flex items-center justify-center text-center border border-slate-100"
                    >
                      {item}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default HealthScore;
