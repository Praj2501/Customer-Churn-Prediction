
import { Button } from '@/components/ui/button';
import { useEffect } from 'react';

export function Hero() {
  useEffect(() => {
    // Animation for elements with .animate-on-scroll class
    const animateOnScrollObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
          }
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll('.animate-on-scroll').forEach((element) => {
      animateOnScrollObserver.observe(element);
    });

    return () => {
      document.querySelectorAll('.animate-on-scroll').forEach((element) => {
        animateOnScrollObserver.unobserve(element);
      });
    };
  }, []);
  
  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
      {/* Abstract gradient background */}
      <div className="absolute inset-0 bg-gradient-radial from-slate-50 to-white z-0"></div>
      <div className="absolute top-1/4 right-0 w-3/4 h-3/4 bg-blue-50 rounded-full blur-3xl opacity-30 z-0"></div>
      <div className="absolute bottom-0 left-0 w-1/2 h-1/2 bg-blue-100 rounded-full blur-3xl opacity-20 z-0"></div>
      
      {/* Grid accent */}
      <div 
        className="absolute inset-0 z-0 opacity-[0.03]" 
        style={{ 
          backgroundImage: 'linear-gradient(#94a3b8 1px, transparent 1px), linear-gradient(to right, #94a3b8 1px, transparent 1px)',
          backgroundSize: '40px 40px'
        }}
      ></div>
      
      <div className="container max-w-7xl mx-auto px-6 lg:px-10 relative z-10">
        <div className="flex flex-col items-center justify-center text-center">
          {/* Eyebrow text */}
          <div className="animate-on-scroll mb-4">
            <span className="bg-blue-50 text-blue-600 text-xs font-medium px-3 py-1 rounded-full border border-blue-100">
              AI-Powered Customer Retention
            </span>
          </div>
          
          {/* Headline */}
          <h1 className="animate-on-scroll heading-xl max-w-4xl text-slate-900 mb-6 text-balance">
            Predict & Prevent Customer Churn with Advanced AI
          </h1>
          
          {/* Subheadline */}
          <p className="animate-on-scroll delay-100 text-lg md:text-xl text-slate-600 max-w-2xl mb-8 text-balance">
            BizPredict helps businesses identify at-risk customers before they leave, using machine learning to turn data into retention strategies.
          </p>
          
          {/* CTA Buttons */}
          <div className="animate-on-scroll delay-200 flex flex-col sm:flex-row gap-4 mb-16">
            <Button size="lg" className="rounded-full px-8">
              Start Free Trial
            </Button>
            <Button variant="outline" size="lg" className="rounded-full px-8">
              Schedule Demo
            </Button>
          </div>
          
          {/* Dashboard Preview */}
          <div className="animate-on-scroll delay-300 w-full max-w-5xl mx-auto relative">
            {/* Blob decorative elements */}
            <div className="absolute -top-10 -left-10 w-40 h-40 bg-blue-400 rounded-full mix-blend-multiply blur-3xl opacity-10 animate-pulse-slow"></div>
            <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-blue-300 rounded-full mix-blend-multiply blur-3xl opacity-10 animate-pulse-slow animation-delay-1000"></div>
            
            {/* Dashboard image with glass effect */}
            <div className="glass-panel overflow-hidden p-1 md:p-2">
              <div className="flex items-center px-4 py-2 border-b border-slate-100">
                <div className="flex space-x-2">
                  <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                  <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                  <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                </div>
                <div className="mx-auto text-xs text-slate-400">BizPredict Dashboard</div>
              </div>
              
              <div className="bg-gradient-mesh p-2 md:p-6 rounded-b-xl">
                <img 
                  src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" 
                  alt="BizPredict Dashboard"
                  className="w-full h-auto rounded-lg shadow-lg"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Hero;
