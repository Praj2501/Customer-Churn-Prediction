
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useState, createContext, useContext, useEffect } from "react";
import Index from "./pages/Index";
import DataUpload from "./pages/DataUpload";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";
import SignUp from "./pages/SignUp";
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import AnalysisResults from "./pages/AnalysisResults";
import AdminDashboard from "./pages/AdminDashboard";
import Chatbot from "./components/ui/Chatbot";
import { db } from "./services/database";

// Create authentication context
export type User = {
  id: string;
  email: string;
  name: string;
  isPremium: boolean;
  uploadCount?: number;
  maxUploads?: number;
};

type AuthContextType = {
  user: User | null;
  login: (email: string, password: string, isPremium?: boolean) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
};

export const AuthContext = createContext<AuthContextType>({
  user: null,
  login: async () => {},
  logout: () => {},
  isAuthenticated: false,
});

export const useAuth = () => useContext(AuthContext);

// Create query client
const queryClient = new QueryClient();

const App = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for saved user in localStorage
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string, isPremium: boolean = false) => {
    // For demo purposes, we'll create a mock login
    // In a real app, this would validate against MongoDB
    if (email && password.length >= 6) {
      try {
        // Check if the user exists in database
        let userData = await db.findUserByEmail(email);
        
        if (!userData) {
          // Create new user if not found
          userData = await db.createUser({
            email,
            name: email.split('@')[0],
            isPremium: isPremium
          });
        } else {
          // Update last login time and premium status if needed
          await db.updateUserLoginTime(userData.id);
          if (isPremium !== userData.isPremium) {
            await db.updateUserPremiumStatus(userData.id, isPremium);
            userData.isPremium = isPremium;
          }
        }
        
        const mockUser: User = {
          id: userData.id,
          email: userData.email,
          name: userData.name,
          isPremium: userData.isPremium,
          uploadCount: userData.uploadCount,
          maxUploads: userData.maxUploads
        };
        
        setUser(mockUser);
        localStorage.setItem('user', JSON.stringify(mockUser));
        return Promise.resolve();
      } catch (error) {
        return Promise.reject(new Error('Login failed'));
      }
    }
    return Promise.reject(new Error('Invalid credentials'));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  // Route protection component
  const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
    const { isAuthenticated } = useAuth();
    return isAuthenticated ? <>{children}</> : <Navigate to="/login" />;
  };

  if (isLoading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  return (
    <AuthContext.Provider value={{ 
      user, 
      login, 
      logout,
      isAuthenticated: !!user 
    }}>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<SignUp />} />
              <Route path="/data-upload" element={
                <ProtectedRoute>
                  <DataUpload />
                </ProtectedRoute>
              } />
              <Route path="/dashboard" element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              } />
              <Route path="/admin-dashboard" element={
                <ProtectedRoute>
                  <AdminDashboard />
                </ProtectedRoute>
              } />
              <Route path="/profile" element={
                <ProtectedRoute>
                  <Profile />
                </ProtectedRoute>
              } />
              <Route path="/settings" element={
                <ProtectedRoute>
                  <Settings />
                </ProtectedRoute>
              } />
              <Route path="/analysis-results/:id" element={
                <ProtectedRoute>
                  <AnalysisResults />
                </ProtectedRoute>
              } />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
            <Chatbot position="bottom-right" />
          </BrowserRouter>
        </TooltipProvider>
      </QueryClientProvider>
    </AuthContext.Provider>
  );
};

export default App;
